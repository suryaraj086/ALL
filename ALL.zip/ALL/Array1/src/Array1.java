import java.util.ArrayList;

public class Array1 {

	static ArrayList<Integer> leaders(int arr[], int n) {

		ArrayList<Integer> list = new ArrayList<Integer>();
		int i = 0, j = arr.length - 1;
		while (i <= j) {
			if (i == j && i < arr.length - 1) {
				list.add(arr[i]);
				j = arr.length - 1;
				i++;
			}
			if (arr[i] > arr[j]) {
				j--;
			} else {
				i++;
				j = arr.length - 1;
			}
		}
		list.add(arr[arr.length - 1]);
		return list;
	}

	long maxSubarraySum(int arr[], int n) {
		long msum = Integer.MIN_VALUE;
		long sum = 0;
		for (int i = 0; i < n; i++) {
			sum += arr[i];
			msum = Math.max(sum, msum);
			if (sum < 0) {
				sum = 0;
			}
		}
		return msum;

	}

	public static void main(String[] args) {
		Array1 arrObj = new Array1();
		int[] arr = { 31, 40, 93, 40, 98 };
		System.out.println(leaders(arr, arr.length));
	}

}
