import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Set;
import java.util.*;

class Preparation {
	String encode(String str) {
		String out = "";
		int count = 0;
		for (int i = 0; i < str.length(); i++) {
			count = 1;
			while (i < str.length() - 1 && str.charAt(i) == str.charAt(i + 1)) {
				i++;
				count++;
			}
			out += str.charAt(i) + "" + count;
		}
		return out;
	}

	String findSum(String X, String Y) {
		BigInteger x1 = new BigInteger(X);
		BigInteger y1 = new BigInteger(Y);
		x1 = x1.add(y1);
		return x1.toString();
	}

	public static void merge(long arr1[], long arr2[], int n, int m) {
		Map<Long, Integer> map = new HashMap<Long, Integer>();
		for (int i = 0; i < n; i++) {
			map.put(arr1[i], 1);
		}
		for (int i = 0; i < m; i++) {
			map.put(arr2[i], 1);
		}
		Set<Long> keys = map.keySet();
		Long[] array = keys.toArray(new Long[keys.size()]);
		arr1 = Arrays.copyOf(arr1, keys.size());
		for (int i = 0; i < keys.size(); i++) {
			arr1[i] = array[i];
		}
	}

	boolean kPangram(String str, int k) {
		// code here
		int map[] = new int[26];
		Arrays.fill(map, 0);
		int total = 0;
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) == ' ')
				continue;
			map[(int) str.charAt(i) - (int) 'a']++;
			total++;
		}
		if (total < 26)
			return false;
		int count = 0;
		for (int i = 0; i < 26; i++) {
			if (map[i] != 0)
				count++;
		}
		if (count + k >= 26)
			return true;
		return false;
	}

	public static int wordBreak(String A, ArrayList<String> B) {
		int n = A.length();
		boolean[] dp = new boolean[n + 1];
		Collections.reverse(B);
		dp[n] = true;
		for (int i = n - 1; i >= 0; i--) {
			for (int j = i + 1; j <= n; j++) {
				if (B.contains(A.substring(i, j)) && dp[j]) {
					dp[i] = true;
					break;
				}
			}
		}
		return dp[0] ? 1 : 0;
	}

	public static void main(String[] args) {
		Preparation obj = new Preparation();
		System.out.println("This is return " + obj.encode("aaaabbbccc"));
//		System.out.print("This is return "+obj.findSum("709396412620629286296078368866266297068421405425244843899898426245063817157711255932243423295811517100838801957742186421740441523535518511718404612557651698950423196258329381762117874254279211732357101259328759749184501645918245187322484251447365937301814839359003461099133981675607708284331451799198213721901661362382936071361",
//				"39031371702810453098018578414127242601772955922421455202353987804064231649151415780203758048048457872157064128708940216242047104883098924639621"));
//	
//		System.out.println(obj.find_permutation("ABC"));
//		System.out.println(obj.kPangram("aaaaaaaaaaaaaaaaaaaaaaaaa",25));
		ArrayList<String> B = new ArrayList<String>(Arrays.asList("i", "like", "sam", "sung", "samsung", "mobile",
				"ice", "cream", "icecream", "man", "go", "mango"));
		String A = "ice";
		System.out.println(Preparation.wordBreak(A, B));
	}
}