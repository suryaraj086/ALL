
public enum ApprovedStatus {
	APPROVED, NOT_APPROVED, PENDING
}
