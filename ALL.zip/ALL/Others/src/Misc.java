import java.util.ArrayList;

public class Misc {

	static int[] x = { -1, -1, -1, 0, 0, 1, 1, 1 };
	static int[] y = { -1, 0, 1, -1, 1, -1, 0, 1 };

	public boolean stringInGrid(char grid[][], String word) {
		ArrayList<Integer> list = new ArrayList<>();
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[0].length; j++) {
				if (search(grid, i, j, word)) {
					return true;
				}

			}
		}
		return false;
	}

	public boolean search(char[][] grid, int row, int column, String word) {
		if (grid[row][column] != word.charAt(0)) {
			return false;
		}

		for (int dir = 0; dir < 8; dir++) {
			int rd = row + x[dir], cd = column + y[dir];
			int length = word.length();
			int k = 0;
			for (k = 1; k < length; k++) {
				if (rd < 0 || cd < 0 || rd >= grid.length || cd >= grid[0].length) {
					break;
				}
				if (grid[rd][cd] != word.charAt(k)) {
					break;
				}
				rd += x[dir];
				cd += y[dir];
			}

			if (k == word.length()) {
				return true;
			}

		}
		return false;
	}

	public ArrayList<String> stringInGrid(int grid[][], int word) {
		ArrayList<String> arr = new ArrayList<String>();
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[0].length; j++) {
				search(grid, i, j, word, arr);
			}
		}
		return arr;
	}

	public boolean search(int[][] grid, int row, int column, int word, ArrayList<String> arr) {

		for (int dir = 0; dir < 8; dir++) {
			int rd = row, cd = column;
			int length = 2;
			int k = 0;
			int temp = 0;
			for (k = 0; k < length; k++) {

				if (rd < 0 || cd < 0 || rd >= grid.length || cd >= grid[0].length) {
					break;
				}
				temp += grid[rd][cd];
				if (temp == word) {
					arr.add(grid[rd][cd] + "+" + grid[row][column]);
					return true;
				}
				rd += x[dir];
				cd += y[dir];
			}
		}

		return false;
	}

	public static void main(String[] args) {
		Misc obj = new Misc();
//		char[][] temp = { { 'F', 'A', 'C', 'I' }, { 'O', 'B', 'Q', 'P' }, { 'A', 'N', 'O', 'B' },
//				{ 'M', 'A', 'S', 'S' } };
//		System.out.println(obj.stringInGrid(temp, "HI"));

		int[][] val = { { 1, 3, 4, 6, 2 }, { 3, 5, 8, 9, 0 }, { 1, 7, 3, 2, 4 }, { 2, 3, 1, 4, 2 }, { 6, 4, 3, 2, 1 } };

		System.out.println(obj.stringInGrid(val, 10));

	}

}
