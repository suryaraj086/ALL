
public enum TaxiState {
	IDLE, BUSY
}
