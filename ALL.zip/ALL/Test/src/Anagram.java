import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Anagram {

	public List<List<String>> checkAnagram(String[] arr) throws Exception {
		Map<String, List<String>> map = new HashMap<>();
		for (String inp : arr) {
			nullChecker(inp);
			char[] array = inp.toCharArray();
			Arrays.sort(array);
			String temp = "";
			for (int i = 0; i < array.length; i++) {
				temp += array[i];
			}
			if (map.containsKey(temp)) {
				List<String> list = map.get(temp);
				list.add(inp);
			} else {
				List<String> list = new ArrayList<String>();
				list.add(inp);
				map.put(temp, list);
			}
		}
		List<List<String>> arrList = new ArrayList<List<String>>();
		for (String val : map.keySet()) {
			List<String> list = map.get(val);
			arrList.add(list);

		}
		return arrList;
	}

	public void nullChecker(String inp) throws Exception {
		if (inp == null) {
			throw new Exception("String cannot be null");
		}
	}

	public static void main(String[] args) {
		Anagram obj = new Anagram();
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the length of array");
		int length = scan.nextInt();
		String[] arr = new String[length];
		scan.nextLine();
		for (int i = 0; i < length; i++) {
			arr[i] = scan.nextLine();
		}
		try {
			System.out.println(obj.checkAnagram(arr));
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		scan.close();
	}
}
