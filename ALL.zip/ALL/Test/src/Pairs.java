import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Pairs {

	public int countPairs(int[] arr, int k) {
		Map<Integer, Integer> map = new HashMap<>();
		int count = 0;
		for (int i = 0; i < arr.length; i++) {
			if (map.get(k - arr[i]) != null) {
				count++;
			} else {
				map.put(arr[i], 0);
			}
		}
		return count;
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Pairs pObj = new Pairs();
		System.out.println("Enter the length of the array");
		int length = scan.nextInt();
		int[] inp = new int[length];
		for (int i = 0; i < length; i++) {
			inp[i] = scan.nextInt();
		}
		System.out.println("Enter the value");
		int val = scan.nextInt();
		System.out.println("The total pairs are " + pObj.countPairs(inp, val));
		scan.close();
	}

}
