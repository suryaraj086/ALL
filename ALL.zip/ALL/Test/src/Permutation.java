import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Permutation {

	public List<List<Integer>> checkPermuatation(int[] arr) {
		List<List<Integer>> arrList = new ArrayList<List<Integer>>();

		for (int i = 0; i < arr.length; i++) {
			List<Integer> temp = new ArrayList<Integer>();
			List<Integer> temp1 = new ArrayList<Integer>();
			temp.add(arr[i]);
			temp1.add(arr[i]);
			for (int j = 0; j < arr.length; j++) {
				if (i != j) {
					temp.add(arr[j]);
				}
			}
			for (int j = arr.length - 1; j >= 0; j--) {
				if (i != j) {
					temp1.add(arr[j]);
				}
			}
			arrList.add(temp);
			if (temp1.size() > 2) {
				arrList.add(temp1);
			}
		}
		return arrList;
	}

//	public int[] swap(int i, int j, int[] arr) {
//		int temp = arr[i];
//		arr[i] = arr[j];
//		arr[j] = temp;
//		return arr;
//	}

	public static void main(String[] args) {
		Permutation pObj = new Permutation();
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the length of the array");
		int length = scan.nextInt();
		int[] arr = new int[length];
		for (int i = 0; i < length; i++) {
			arr[i] = scan.nextInt();
		}
		System.out.println(pObj.checkPermuatation(arr));
		scan.close();
	}

}
