import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Test {

	public int firstDuplicate(int[] arr) {
		List<Integer> temp = new ArrayList<>();
		for (int i = 0; i < arr.length; i++) {
			if (!temp.contains(arr[i])) {
				temp.add(arr[i]);
			} else {
				return arr[i];
			}
		}
		return -1;
	}

	public List<String> findPermutation(int[] arr) {

		List<String> permu = new ArrayList<String>();
		String s = "";
		for (int i : arr) {
			s += i + "";
		}
		permute1(s, "", permu);
		Collections.sort(permu);
		return permu;
	}

	private void permute1(String s, String out, List<String> permu) {
		if (out != "" || s.length() == 0) {
			permu.add(out);
		}
		for (int i = 0; i < s.length(); i++) {
			char ch = s.charAt(i);
			String ans = s.substring(0, i) + s.substring(i + 1);
			permute1(ans, out + ch, permu);
		}
	}

	public static void main(String[] args) {
		Test obj = new Test();
		Scanner scan = new Scanner(System.in);
		System.out.println("1.Find duplicate String");
		int val = scan.nextInt();
		switch (val) {
		case 1:
			System.out.println("Enter the length of an array");
			int length = scan.nextInt();
			int[] arr = new int[length];
			for (int i = 0; i < length; i++) {
				arr[i] = scan.nextInt();
			}
			System.out.println(obj.firstDuplicate(arr));
			break;

		default:
			break;
		}
		scan.close();
	}
}
