
public enum Role {
	agent, user
}
