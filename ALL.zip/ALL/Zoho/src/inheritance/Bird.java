package inheritance;

public abstract class Bird {

	public abstract void fly();
	public String speak() {
		return "i can't speak";
	}
	
}
