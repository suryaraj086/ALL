package inheritance;
public abstract class BirdAbstract {

	public String fly() {
		return "fly method invoked";
	}

	public String speak() {
		return "speak method invoked";
	}
	
}
