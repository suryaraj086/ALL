package inheritance;

public class Duck extends Bird {
	
	@Override public void fly() {
		System.out.println("i can't fly");
	}


}
