package inheritance;
public class ParrotMod extends BirdAbstract{
	

}
