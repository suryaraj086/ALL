package filesystem;

public enum Command {
	addFile(1), addHiddenFile(2);

	Command(int i) {
	}
}
