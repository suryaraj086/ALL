package filesystem;

import java.util.HashMap;
import java.util.Map;

public class FileSystem {

	Map<String, Map<String, File>> file = new HashMap<>();
	Map<String, Map<String, File>> deleted = new HashMap<String, Map<String, File>>();

	public FileSystem() {
		File data = new File();
		data.setFileName("temp");
		data.setData("temp");
		Map<String, File> map = new HashMap<String, File>();
		map.put(data.getFileName(), data);
		file.put("/ZOHO/CS/", map);
	}

	public String subDirectories(String directory) {
		String subDir = "";
		for (String dir : file.keySet()) {
			if (dir.contains(directory)) {
				subDir += dir + "\n";
			}
		}
		return subDir;
	}

	public boolean addFile(File inp) {
		Map<String, File> temp = file.get("/ZOHO/CS/");
		if (temp == null) {
			temp = new HashMap<>();
		}
		temp.put(inp.getFileName(), inp);
		System.out.println(inp);
		return true;
	}

	public boolean addDir(String directory) {
		file.put(directory, null);
		return true;
	}

	public boolean setContents(String dir, String filename, String content) throws Exception {
		Map<String, File> temp = file.get(dir);
		File data = temp.get(filename);
		deletedCheck(data);
		readOnlyChecker(data);
		data.setData(content);
		return true;
	}

	public void changeReadOnly(String filename, String path) throws Exception {
		Map<String, File> map = file.get(path);
		nullChecker(map);
		File data = map.get(filename);
		deletedCheck(data);
		data.setReadonly(true);
	}

	public String getContent(String dir, String filename) throws Exception {
		Map<String, File> temp = file.get(dir);
		File data = temp.get(filename);
		deletedCheck(data);
		return data.getData();
	}

	public String listFile() {
		String data = "";
		for (Map<String, File> temp1 : file.values()) {
			for (File temp : temp1.values())
				if (!hiddenChecker(temp) && !deletedChecker(temp)) {
					data += temp.getFileName() + "\n";
				}
		}
		return data;
	}

	public String listAllFile() {
		String data = "";
		for (Map<String, File> temp1 : file.values()) {
			for (File temp : temp1.values())
				if (!deletedChecker(temp)) {
					data += temp.getFileName() + "\n";
				}
		}
		return data;
	}

	public boolean deleteFile(String dir, String filename) throws Exception {
		Map<String, File> deleteMap = file.get(dir);
		File toDelete = deleteMap.get(filename);
		deletedCheck(toDelete);
		toDelete.setDeleted(true);
		return true;
	}

	public String listDir() {
		String out = "";
		for (String temp : file.keySet()) {
			out += "Directory" + temp + " and total files are "  + "\n";
		}
		return out;
	}

	public void nullChecker(Object inp) throws Exception {
		if (inp == null) {
			throw new Exception("File not found");
		}
	}

	public boolean hiddenChecker(File inp) {
		return inp.isHidden();
	}

	public boolean deletedChecker(File inp) {
		return inp.isDeleted();
	}

	public void readOnlyChecker(File obj) throws Exception {
		if (obj.isReadonly()) {
			throw new Exception("The file is read only");
		}
	}

	public void deletedCheck(File inp) throws Exception {
		if (inp.isDeleted() || inp == null) {
			throw new Exception("Deleted file or file not found");
		}
	}
}
