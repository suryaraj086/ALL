package filesystem;

import java.util.Scanner;

public class SystemRunner {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		FileSystem fObj = new FileSystem();
		boolean bool = true;
		while (bool) {
			System.out.println("1. Add file ( command - addFile <filename> ). Assume default file size of 10 bytes."
					+ "\n2. Add hidden file ( command - addHiddenFile )."
					+ "\n3. Add directory ( command - addDir <directory name> )."
					+ "\n4. Set contents inside a file ( command - setContent directory/filename content )."
					+ "\n5. Get content from file ( command - getContent directory/filename )."
					+ "\n6. Allow users to set file access permissions - like readOnly or read write, ( command - setReadOnly <filename> )."
					+ "\n7. Traverse directory ( command - goDir <any subdirectory name at one level>, goPrevDirectory<the previous directory in the hierarchy> )."
					+ "\n8. List files in any directory ( command - listFiles )."
					+ "\n9. List all files ( including hidden files ) ( command - listAllFiles )."
					+ "\n10. Details command - listDetails."
					+ "\n11. List directory details like the size of the directory, and the number of files ( command details )."
					+ "\n12. A file or directory can be deleted. ( command - removeFile/removeDir ).");
			int val = scan.nextInt();
			scan.nextLine();
			switch (val) {
			case 1: {
				File file = new File();
				System.out.println("Enter the file name");
				String name = scan.nextLine();
				System.out.println("Enter the content");
				String content = scan.nextLine();
				file.setData(content);
				file.setFileName(name);
				fObj.addFile(file);
				System.out.println("Added");
				break;
			}
			case 2: {
				break;
			}
			case 3: {
				System.out.println("Enter the directory");
				String directory = scan.nextLine();
				fObj.addDir(directory);
				System.out.println("Durectory added successfully");
				break;
			}
			case 4: {
				System.out.println("Enter the directory");
				String directory = scan.nextLine();
				System.out.println("Enter the file name");
				String name = scan.nextLine();
				System.out.println("Enter the Content");
				String content = scan.nextLine();
				try {
					fObj.setContents(directory, name, content);
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				System.out.println("Added successfully");
				break;
			}
			case 5: {
				System.out.println("Enter the directory");
				String directory = scan.nextLine();
				System.out.println("Enter the file name");
				String name = scan.nextLine();
				try {
					System.out.println(fObj.getContent(directory, name));
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				break;
			}
			case 6: {
				System.out.println("Enter the directory");
				String directory = scan.nextLine();
				System.out.println("Enter the file name");
				String name = scan.nextLine();
				try {
					fObj.changeReadOnly(directory, name);
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				System.out.println("Status changed to readonly");
				break;
			}
			case 7: {
				System.out.println(fObj.listDir());

				for (int i = 1; i > 0; i++) {
					int value = scan.nextInt();
					if (value == 0) {
						break;
					}

				}
				break;
			}
			case 8: {
				System.out.println(fObj.listFile());
				break;
			}
			case 9: {
				System.out.println("All files are ");
				System.out.println(fObj.listAllFile());
				break;
			}
			case 10: {
				System.out.println(fObj.listDir());
				break;
			}
			case 11: {
				System.out.println("Enter the directory");
				String directory = scan.nextLine();
				System.out.println("Enter the file name");
				String name = scan.nextLine();
				try {
					System.out.println(fObj.deleteFile(directory, name));
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				System.out.println("Deleted");
			}
			}
		}
		scan.close();
	}
}
