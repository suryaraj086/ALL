package librarymanagement;

public class Book {

	private int rackNo;
	private int uniqueId;
	public String author;
	private String title;
	private long publicationDate;
	private int barcode;

	public int getBarcode() {
		return barcode;
	}

	public void setBarcode(int barcode) {
		this.barcode = barcode;
	}

	public int getRackNo() {
		return rackNo;
	}

	public void setRackNo(int rackNo) {
		this.rackNo = rackNo;
	}

	public int getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(int uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public long getPublicationDate() {
		return publicationDate;
	}

	public void setPublicationDate(long publicationDate) {
		this.publicationDate = publicationDate;
	}

	@Override
	public String toString() {
		return "Book [rackNo=" + rackNo + ", uniqueId=" + uniqueId + ", author=" + author + ", title=" + title
				+ ", publicationDate=" + publicationDate + ", barcode=" + barcode + "]";
	}

}
