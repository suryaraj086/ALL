package librarymanagement;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class BookComp implements Comparator<Book> {
	@Override
	public int compare(Book s1, Book s2) {
		if (s1.getTitle() == s2.getTitle()) {
			return 0;
		}
		return -1;
	}
}

public class LibraryManager {
	List<Book> bookMap = new ArrayList<Book>();
	Map<Integer, List<Book>> booked = new HashMap<>();
	Map<Integer, Users> userMap = new HashMap<>();
	Map<Integer, Integer> reserved = new HashMap<Integer, Integer>();

	LibraryManager() {
		Book obj = ObjectSetter.bookSetter("Dharma", "HeadFirst", 1, 1);
		Book obj1 = ObjectSetter.bookSetter("Dharmashastha", "HeadSecond", 1, 2);
		bookMap.add(obj);
		bookMap.add(obj1);
	}

	public Book search(Book book) {
		int index = Collections.binarySearch(bookMap, book, new BookComp());
		return bookMap.get(index);
	}

}
