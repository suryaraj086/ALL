package librarymanagement;

import java.util.Scanner;

public class LibraryRunner {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		LibraryManager library = new LibraryManager();
		Book obj = new Book();
		obj.setTitle("HeadFirst");
		System.out.println(library.search(obj));
		scan.close();
	}

}
