package librarymanagement;

public class ObjectSetter {

	public static Book bookSetter(String author, String title, int rackNo, int id) {
		Book obj = new Book();
		obj.setAuthor(author);
		obj.setTitle(title);
		obj.setRackNo(rackNo);
		obj.setUniqueId(id);
		return obj;
	}

}
