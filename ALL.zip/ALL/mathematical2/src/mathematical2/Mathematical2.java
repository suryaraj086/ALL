package mathematical2;

import java.util.*;

public class Mathematical2 {

	public Long primeFactors(int n) {

		TreeSet<Long> t = new TreeSet<>();
		t.add(1L);
		int i = 1;
		while (i < n) {
			long temp = t.pollFirst();
			t.add(temp * 2);
			t.add(temp * 3);
			t.add(temp * 5);
			i++;
		}
		return t.pollFirst();
	}

	static int monthDays[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

	static int noOfDays(int d1, int m1, int y1, int d2, int m2, int y2) {
		int n1 = y1 * 365 + d1;
		for (int i = 0; i < m1 - 1; i++) {
			n1 += monthDays[i];
		}
		n1 += countLeapYears(y1, m1);
		int n2 = y2 * 365 + d2;
		for (int i = 0; i < m2 - 1; i++) {
			n2 += monthDays[i];
		}
		n2 += countLeapYears(y2, m2);

		return Math.abs(n2 - n1);
	}

	static int countLeapYears(int y, int m) {
		int years = y;

		if (m <= 2) {
			years--;
		}
		return years / 4 - years / 100 + years / 400;
	}

	public void maxPrime(long n) {
		String temp = n + "";
		char[] ch = temp.toCharArray();
		Arrays.sort(ch);
		temp = "";
		for (int i = ch.length - 1; i >= 0; i--) {
			temp += ch[i];
		}
		if (Long.parseLong(temp) % 2 != 0) {
			System.out.println(temp);
		}
	}

	public String removeDigits(int n) {
		StringBuilder str = new StringBuilder(n + "");
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			str = str.replace(i, i + 1, "");
			if (Integer.parseInt(str.toString()) % 8 == 0) {
				return str.toString();
			}
			str.replace(i, i, ch + "");
		}
		return "No";
	}

	public int largestDigit(long n, int d) {
		String inp = n + "";
		int index = inp.indexOf(d + "");
		inp = inp.substring(index);
		int count = 0;
		for (int i = 0; i < inp.length(); i++) {
			int temp = Integer.parseInt(inp.charAt(i) + "");
			if (count < temp) {
				count = temp;
			}
		}
		return count;
	}

	static int x[] = { -1, -1, -1, 0, 0, 1, 1, 1 };
	static int y[] = { -1, 0, 1, -1, 1, -1, 0, 1 };
	static int temp1 = 0;
	static int temp = 0;

	public int queenPath(int N, int x, int y, int[] kx1, int kx2[]) {
		int[][] grid = new int[N][N];
		for (int i = 0; i < kx1.length; i++) {
			grid[kx1[i]][kx2[i]] = 1;
		}
		grid[x][y] = 2;
		search(grid, x, y, 2);
		return temp1;

	}

	static boolean search(int[][] grid, int row, int col, int num) {

		for (int dir = 0; dir < 8; dir++) {
			int k, rd = row + x[dir], cd = col + y[dir];
			int wordLen = grid.length;
			for (k = 0; k < wordLen; k++) {
				if (rd >= grid.length || rd < 0 || cd >= grid[0].length || cd < 0) {
					break;
				}
				if (grid[rd][cd] != 0) {
					break;
				}
				rd += x[dir];
				cd += y[dir];
				temp1++;
			}
		}
		return false;
	}

	public String hexaToBinary(String inp) {
		Map<Character, String> map = new HashMap<Character, String>();
		map.put('A', "1010");
		map.put('B', "1011");
		map.put('C', "1100");
		map.put('D', "1101");
		map.put('E', "1110");
		map.put('F', "1111");
		String out = "";
		for (int i = 0; i < inp.length(); i++) {
			char temp = inp.charAt(i);
			if (temp > '0' && temp < '9') {
				out += binary(Integer.parseInt(temp + ""));
			} else {
				out += map.get(temp);
			}
		}
		return out;
	}

	public String binary(int n) {
		String temp = "";
		while (n > 0) {
			temp = n % 2 + temp;
			n = n / 2;
		}
		while (temp.length() < 4) {
			temp = "0" + temp;
		}
		return temp;
	}

//	public String hexa(String inp) {
//		String temp = "";
//		while (n > 0) {
//			temp = n % 2 + temp;
//			n = n / 2;
//		}
//		while (temp.length() < 4) {
//			temp = "0" + temp;
//		}
//		return temp;
//	}

//	public String binaryToHexa(String inp) {
//
//		return inp;
//	}

	public int palindrome(int n) {
		int count = 0;
		int val = 10;
		return isPalindrome(n, count, val);
	}

	public int isPalindrome(int n, int count, int val) {
		StringBuilder inp = new StringBuilder(val + "");
		String temp = inp.toString();
		if (count == n) {
			return --val;
		}
		if (temp.equals(inp.reverse().toString())) {
			return isPalindrome(n, ++count, ++val);
		}
		return isPalindrome(n, count, ++val);
	}

	public static void main(String[] args) {
		Mathematical2 mObj = new Mathematical2();
		Scanner scan = new Scanner(System.in);
		int choice = scan.nextInt();
		switch (choice) {
		case 1:
			System.out.print(mObj.primeFactors(11));
			break;
		case 2:
			mObj.removeDigits(3454);
			break;
		case 3:
			mObj.maxPrime(43196);
			break;
		case 4:
			System.out.print(mObj.largestDigit(14586254, 4));
			break;
		case 5:
			int[] kx1 = { 3 };
			int[] kx2 = { 5 };
			System.out.print(mObj.queenPath(8, 4, 4, kx1, kx2));
			break;
		case 6:
			System.out.print(mObj.hexaToBinary("1AC5"));
			break;
		case 7:
			System.out.print(mObj.palindrome(11));
			break;
		case 8:
			System.out.print(noOfDays(24, 5, 2000, 24, 5, 2022));
			break;

		default:
			break;
		}
		scan.close();
	}
}
