package misc;

import java.util.ArrayList;

public class Misc {

	static int[] x = { -1, -1, -1, 0, 0, 1, 1, 1 };
	static int[] y = { -1, 0, 1, -1, 1, -1, 0, 1 };

	public ArrayList<Integer> stringInGrid(char grid[][], int word) {
		ArrayList<Integer> list = new ArrayList<>();
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[0].length; j++) {
				if (search(grid, i, j, word)) {
					list.add(i);
					list.add(j);
				}

			}
		}
		return list;
	}

	public boolean search(char[][] grid, int row, int column, int word) {
		if (grid[row][column] == word) {
			return true;
		}
		int temp = 0;
		for (int dir = 0; dir < 8; dir++) {
			int rd = row + x[dir], cd = column + y[dir];
			int length = word;
			int k = 0;
			for (k = 1; k < length; k++) {
				if (rd < 0 || cd < 0 || rd >= grid.length || cd >= grid[0].length) {
					break;
				}

				rd += x[dir];
				cd += y[dir];
				temp += grid[rd][cd];
				if (word == temp) {
					return true;
				}
			}
		}
		return false;
	}

	public static void main(String[] args) {
		Misc mObj = new Misc();
	}

}
