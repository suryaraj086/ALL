package mocktest1;

import java.util.*;
import java.util.Map.Entry;

class Compared implements Comparator<Map.Entry<Integer, Integer>> {

	public int compare(Entry<Integer, Integer> o1, Entry<Integer, Integer> o2) {

		if (o1.getValue() > o2.getValue()) {
			return -1;
		} else if (o1.getValue() == o2.getValue()) {
			if (o1.getKey() < o2.getKey()) {
				return 1;
			} else {
				return -1;
			}
		} else if (o1.getValue() > o2.getValue()) {
			return 1;
		}
		return Integer.MIN_VALUE;
	}

}

public class MockTest {

	public boolean stringRotation(String s1, String s2) {
		int n1 = s1.length();
		int n2 = s2.length();
		s1 = s1.toLowerCase();
		s2 = s2.toLowerCase();
		int ind = s2.indexOf(s1.charAt(0));
		int ind1 = s1.lastIndexOf(s2.charAt(0));
		//
		int ind2 = s1.indexOf(s2.charAt(0));
		int ind3 = s2.lastIndexOf(s1.charAt(0));
		System.out.println(s1.contains(s2));
		System.out.println(isContains(s1, s2));
		if (s1.substring(0, ind1).equals(s2.substring(ind, n2))) {
			return true;
		}
		if (s1.substring(ind2, n1).equals(s2.substring(0, ind3))) {
			return true;
		}
		return false;
	}

	public List<String> pairArrays(int[] arr, int sum) {
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		List<String> list = new ArrayList<String>();
		int length = arr.length;
		for (int i = 0; i < length; i++) {
			if (map.get(sum - arr[i]) != null) {
				String out = "(" + arr[i] + "," + (sum - arr[i]) + ")";
				list.add(out);
			} else {
				map.put(arr[i], 0);
			}
		}
		return list;
	}

	public boolean isContains(String s1, String s2) {
		int k = 0;
		for (int i = 0; i < s1.length(); i++) {
			char ch = s2.charAt(k);
			if (s1.charAt(i) == ch) {
				k++;
			} else {
				k = 0;
			}
			if (k == s2.length()) {
				return true;
			}
		}
//		if (k == s2.length()) {
//			return true;
//		}
		return false;
	}

	public String lookAndSay(int n) {
		if (n == 1) {
			return "1";
		}
		if (n == 2) {
			return "11";
		}
		String str = "11";
		String temp = "";
		int count = 1;
		for (int i = 3; i <= n; i++) {
			temp = "";
			str += "$";
			char arr[] = str.toCharArray();
			int length = str.length();
			for (int j = 1; j < length; j++) {
				if (arr[j] != arr[j - 1]) {
					temp += count;
					temp += arr[j - 1];
					count = 1;
				} else {
					count++;
				}
			}
			str = temp;
		}
		return str;
	}

	public List sortFrequency(int[] arr) {
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		int len = arr.length;
		for (int i = 0; i < len; i++) {
			if (map.get(arr[i]) != null) {
				map.put(arr[i], map.get(arr[i]) + 1);
			} else {
				map.put(arr[i], 0);
			}
		}
		List<Map.Entry<Integer, Integer>> list = new ArrayList<Map.Entry<Integer, Integer>>(map.entrySet());
		Collections.sort(list, new Compared());
		ArrayList<Integer> ans = new ArrayList<Integer>();
		for (int i = 0; i < map.size(); i++) {
			int count = list.get(i).getValue();
			while (count >= 0) {
				ans.add(list.get(i).getKey());
				count--;
			}
		}
		return ans;
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		MockTest mObj = new MockTest();
		int choice = scan.nextInt();
		scan.nextLine();
		switch (choice) {
		case 1: {
			System.out.println("Enter the string1");
			String s1 = scan.nextLine();
			System.out.println("Enter the string2");
			String s2 = scan.nextLine();
			System.out.print(mObj.stringRotation(s1, s2));
			break;
		}
		case 2: {
			System.out.println("Enter array length");
			int len = scan.nextInt();
			int[] arr = new int[len];
			System.out.println("Enter the array");
			for (int i = 0; i < len; i++) {
				arr[i] = scan.nextInt();
			}
			System.out.println("Enter the sum");
			int sum = scan.nextInt();
			System.out.print(mObj.pairArrays(arr, sum));
			break;
		}
		case 3: {
			int n = scan.nextInt();
			System.out.print(mObj.lookAndSay(n));
			break;
		}
		case 4: {
			System.out.println("Enter array length");
			int len = scan.nextInt();
			int[] arr = new int[len];
			System.out.println("Enter the array");
			for (int i = 0; i < len; i++) {
				arr[i] = scan.nextInt();
			}
			System.out.print(mObj.sortFrequency(arr));
			break;
		}
		default:
			break;
		}
	}
}
