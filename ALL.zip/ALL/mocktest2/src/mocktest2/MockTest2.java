package mocktest2;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class Node {
	int data;
	Node left;
	Node right;

	Node(int data) {
		this.data = data;
		left = null;
		right = null;
	}

	static void print(Node root) {
		if (root == null) {
			return;
		}
		print(root.left);
		System.out.print(root.data);
		print(root.right);
	}
}

public class MockTest2 {

	public boolean validIp(String inp) {
		if (inp.charAt(inp.length() - 1) == '.' || inp.charAt(0) == '.') {
			return false;
		}
		String[] arr = inp.split("\\.");
		int length = arr.length;
		if (length != 4) {
			return false;
		}
		for (int i = 0; i < length; i++) {
			if (arr[i] == "" || (arr[i].length() > 1 && arr[i].charAt(0) == '0')) {
				return false;
			}
			int temp = Integer.parseInt(arr[i]);
			if (temp < 0 || temp > 255) {
				return false;
			}
		}
		return true;
	}

	public Map<Integer, Integer> duplicates(int[] arr) {
		Arrays.sort(arr);
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		int count = 1;
		int length = arr.length;
		for (int i = 0; i < length; i++) {
			while (i < length - 1 && arr[i] == arr[i + 1]) {
				count++;
				i++;
			}
			map.put(arr[i], count);
			count = 1;
		}
		return map;
	}

	public int[][] rotate(int[][] matrix) {
		int k = matrix.length - 1;
		int[][] temp = new int[matrix.length][matrix[0].length];
		for (int j = 0; j < matrix[0].length; j++, k--) {

			for (int i = 0; i < matrix.length; i++) {
				temp[k][i] = matrix[i][j];
			}
		}
		return matrix;
	}

	Node insert(Node root, int key) {
		if (root == null) {
			return new Node(key);
		}

		if (root.data < key) {
			root.right = insert(root.right, key);
		}
		if (root.data > key) {
			root.left = insert(root.left, key);
		}
		return root;
	}

	public Node subTree(Node root, int val) {
		if (root == null) {
			return root;
		}
		if (root.data > val) {
			return subTree(root.left, val);
		} else if (root.data < val) {
			return subTree(root.right, val);
		} else {
			return root;
		}
	}

	public static void main(String args[]) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the choice");
		int choice = scan.nextInt();
		MockTest2 mObj = new MockTest2();
		switch (choice) {
		case 1: {
			System.out.print(mObj.validIp("0.0.0.0"));
			break;
		}
		case 2: {
			System.out.println("Enter the array length");
			int len = scan.nextInt();
			System.out.println("Enter the array");
			int arr[] = new int[len];
			for (int i = 0; i < len; i++) {
				arr[i] = scan.nextInt();
			}
			System.out.print(mObj.duplicates(arr));
			break;
		}

		case 3: {
			int[][] arr = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
			System.out.print(Arrays.deepToString(mObj.rotate(arr)));
			break;
		}
		case 4: {
			System.out.println("Enter the length");
			int len = scan.nextInt();
			System.out.println("Enter the data");
			int data = scan.nextInt();
			Node root = new Node(data);
			for (int i = 0; i < len - 1; i++) {
				data = scan.nextInt();
				root = mObj.insert(root, data);
			}
			Node.print(root);
			System.out.println("Enter the value");
			int value = scan.nextInt();
			root = mObj.subTree(root, value);
			Node.print(root);
			break;
		}

		case 5: {
//			int[] petrol = { 4, 6, 7, 4 };
//			int[] distance = { 6, 5, 3, 5 };
//			System.out.print(mObj.petrolPump(petrol, distance));
			break;
		}
		default:
			break;
		}
		scan.close();
	}
}
