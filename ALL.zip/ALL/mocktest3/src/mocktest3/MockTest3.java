package mocktest3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

class Node {
	int data;
	Node left;
	Node right;

	Node(int val) {
		this.data = val;
	}

	static void print(Node root) {
		if (root == null) {
			return;
		}
		print(root.left);
		System.out.print(root.data);
		print(root.right);

	}
}

public class MockTest3 {

	public int palindrome(int n) {
		int count = 0;
		int val = 10;
		return isPalindrome(n, count, val);
	}

	public int isPalindrome(int n, int count, int val) {
		StringBuilder str = new StringBuilder(val + "");
		String temp = str.toString();
		if (n == count) {
			return --val - 1;
		}
		if (temp.equals(str.reverse().toString())) {
			isPalindrome(n, ++count, ++val);
		}
		return isPalindrome(n, count, ++val);
	}

	public ArrayList<Integer> stringInGrid(char grid[][], String word) {
		ArrayList<Integer> list = new ArrayList<>();
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[0].length; j++) {
				if (search(grid, i, j, word)) {
					list.add(i);
					list.add(j);
				}

			}
		}
		return list;
	}

	static int[] x = { -1, -1, -1, 0, 0, 1, 1, 1 };
	static int[] y = { -1, 0, 1, -1, 1, -1, 0, 1 };

	public boolean search(char[][] grid, int row, int column, String word) {
		if (grid[row][column] != word.charAt(0)) {
			return false;
		}

		for (int dir = 0; dir < 8; dir++) {
			int rd = row + x[dir], cd = column + y[dir];
			int length = word.length();
			int k = 0;
			for (k = 1; k < length; k++) {
				if (rd < 0 || cd < 0 || rd >= grid.length || cd >= grid[0].length) {
					break;
				}
				if (grid[rd][cd] != word.charAt(k)) {
					break;
				}
				rd += x[dir];
				cd += y[dir];
			}

			if (k == word.length()) {
				return true;
			}

		}
		return false;
	}

	public void merge(int arr[], int start, int mid, int end) {
		int temp[] = new int[end - start + 1];
		int i = start, j = mid + 1, k = 0;
		while (i <= mid && j <= end) {
			if (arr[i] <= arr[j]) {
				temp[k] = arr[i];
				k += 1;
				i += 1;
			} else {
				temp[k] = arr[j];
				k += 1;
				j += 1;
			}
		}
		while (i <= mid) {
			temp[k] = arr[i];
			k += 1;
			i += 1;
		}
		while (j <= end) {
			temp[k] = arr[j];
			k += 1;
			j += 1;
		}
		for (i = start; i <= end; i += 1) {
			arr[i] = temp[i - start];
		}
	}

	public void mergeSort(int arr[], int start, int end) {

		if (start < end) {
			int mid = (start + end) / 2;
			mergeSort(arr, start, mid);
			mergeSort(arr, mid + 1, end);
			merge(arr, start, mid, end);
		}
	}

	public static Node insert(Node root, int data) {
		if (root == null) {
			return new Node(data);
		}
		if (root.data > data) {
			root.left = insert(root.left, data);
		}
		if (root.data < data) {
			root.right = insert(root.right, data);
		}

		return root;
	}

	public Node trim(Node root, int low, int high) {
		if (root == null) {
			return root;
		}
		if (root.data < low) {
			root.right = trim(root.right, low, high);
		}
		if (root.data > high) {
			root.left = trim(root.left, low, high);
		}
		return root;
	}

	public ArrayList<Integer> sumS(int[] arr, int sum) {
		ArrayList<Integer> list = new ArrayList<>();
		int temp = 0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = i; j < arr.length; j++) {
				temp += arr[j];
				if (sum == temp) {
					list.add(i + 1);
					list.add(j + 1);
					return list;
				}
			}
			temp = 0;
		}
		return list;
	}

	public static void main(String[] args) {
		MockTest3 mObj = new MockTest3();
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the case");
		int value = scan.nextInt();
		switch (value) {
		case 1:
			System.out.println("Enter the number");
			int temp = scan.nextInt();
			System.out.println(mObj.palindrome(temp));
			break;

		case 2:
//			System.out.println("Enter the number");
//			int length = scan.nextInt();
//			char grid[][] = new char[length][length];
//			for (int i = 0; i < length; i++) {
//				for (int j = 0; j < length; j++) {
//					grid[i][j] = scan.nextLine().charAt(0);
//				}
//			}

			char grid[][] = { { 'a', 'b', 'c' }, { 'a', 'b', 'c' }, { 'a', 'b', 'c' } };
			scan.nextLine();
			System.out.println("Enter the String to find");
			String word = scan.nextLine();
			System.out.println(mObj.stringInGrid(grid, word));
			break;
		case 3:
			System.out.println("Enter the length of array");
			int length1 = scan.nextInt();
			int array[] = new int[length1];
			for (int i = 0; i < length1; i++) {
				array[i] = scan.nextInt();
			}
			mObj.mergeSort(array, 0, length1 - 1);
			System.out.println(Arrays.toString(array));
			break;

		case 4:
			System.out.println("Enter the length");
			int length2 = scan.nextInt();
			System.out.println("Enter the data");
			int val = scan.nextInt();
			Node root = new Node(val);
			for (int i = 0; i < length2 - 1; i++) {
				int data = scan.nextInt();
				root = insert(root, data);
			}
			System.out.println("Enter the low");
			int low = scan.nextInt();
			System.out.println("Enter the high");
			int high = scan.nextInt();
			Node.print(mObj.trim(root, low, high));
			break;

		case 5:
			System.out.println("Enter the length");
			int len = scan.nextInt();
			int[] arr = new int[len];
			for (int i = 0; i < len; i++) {
				arr[i] = scan.nextInt();
			}
			System.out.print("Enter the sum");
			int sum = scan.nextInt();
			System.out.println(mObj.sumS(arr, sum));
			break;

		default:
			break;
		}
		scan.close();
	}
}
