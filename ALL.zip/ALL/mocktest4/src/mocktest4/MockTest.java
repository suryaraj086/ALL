package mocktest4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.TreeMap;

class Node {
	int data;
	Node left;
	Node right;

	Node(int data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "Node [data=" + data + ", left=" + left + ", right=" + right + "]";
	}
}

public class MockTest {

	public int findExtra(int[] a, int[] b) {

		for (int i = 0; i < a.length; i++) {
			if (a[i] != b[i]) {
				return i;
			}
		}
		return -1;
	}

	public TreeMap<Integer, List<Integer>> sortABS(int[] arr, int k) {
		TreeMap<Integer, List<Integer>> map = new TreeMap<Integer, List<Integer>>();
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < arr.length; i++) {
			int temp = Math.abs(k - arr[i]);
			if (map.get(temp) == null) {
				list = new ArrayList<Integer>();
				list.add(arr[i]);
				map.put(temp, list);
			} else {
				list = map.get(temp);
				list.add(arr[i]);
			}
		}
		return map;
	}

	public int noOfOpenDoors(int n) {
		return (int) Math.sqrt(n);
	}

	public int minValue(Node root) {
		if (root != null && root.left == null) {
			return root.data;
		}
		if (root == null) {
			return -1;
		}
		return minValue(root.left);
	}

	public Node insert(Node root, int val) {
		if (root == null) {
			root = new Node(val);
		}
		if (val < root.data) {
			root.left = insert(root.left, val);
		}
		if (val > root.data) {
			root.right = insert(root.right, val);
		}
		return root;
	}

	public char[] shuffle(char[] arr, int[] indices) {
		char[] temp = new char[arr.length];
		for (int i = 0; i < arr.length; i++) {
			temp[indices[i]] = arr[i];
		}
		return temp;
	}

	static ArrayList<Integer> arr = new ArrayList<>();

	static ArrayList<Integer> topView(Node root) {
		leftMost(root);
		rightMost(root);
		return arr;
	}

	static void leftMost(Node root) {
		if (root == null) {
			return;
		}
		leftMost(root.left);
		if (!arr.contains(root.data)) {
			arr.add(root.data);
		}
	}

	static void rightMost(Node root) {
		if (root == null) {
			return;
		}
		if (!arr.contains(root.data)) {
			arr.add(root.data);
		}
		rightMost(root.right);
	}

	public static void main(String[] args) {
		MockTest mObj = new MockTest();
		Scanner scan = new Scanner(System.in);
		System.out.println("1.Find an extra element\n2.sort by absolute difference\n3.minimum element is bst"
				+ "\n4.number of open doors \n5.shuffled string ");
		int val = scan.nextInt();
		switch (val) {
		case 1:
			System.out.println("Enter the length of array");
			int length = scan.nextInt();
			int arr[] = new int[length];
			System.out.println("Enter the data");
			for (int i = 0; i < length; i++) {
				arr[i] = scan.nextInt();
			}
			System.out.println("Enter the length of second array");
			int length1 = scan.nextInt();
			int arr1[] = new int[length1];
			System.out.println("Enter the data");
			for (int i = 0; i < length1; i++) {
				arr1[i] = scan.nextInt();
			}
			System.out.println("The extra element is in " + mObj.findExtra(arr, arr1));
			break;

		case 2:
			System.out.println("Enter the length of array");
			int len = scan.nextInt();
			int arr2[] = new int[len];
			for (int i = 0; i < len; i++) {
				arr2[i] = scan.nextInt();
			}
			System.out.println("Enter the value");
			int num = scan.nextInt();
			System.out.println(mObj.sortABS(arr2, num));
			break;
		case 3:
			System.out.println("Enter the length of Tree");
			int len1 = scan.nextInt();
			System.out.println("Enter the data");
			int data = scan.nextInt();
			Node root = new Node(data);
			for (int i = 0; i < len1 - 1; i++) {
				data = scan.nextInt();
				root = mObj.insert(root, data);
			}
			System.out.println("The minimum element in root is " + mObj.minValue(root));
			break;
		case 4:
			System.out.println("Enter the value");
			int n = scan.nextInt();
			System.out.println(mObj.noOfOpenDoors(n));
			break;
		case 5:
			System.out.println("Enter the length of array");
			int len2 = scan.nextInt();
			char array[] = new char[len2];
			scan.nextLine();
			System.out.println("Enter the data");
			for (int i = 0; i < len2; i++) {
				array[i] = scan.nextLine().charAt(0);
			}
			System.out.println("Enter the array 2");
			int array1[] = new int[len2];
			for (int i = 0; i < len2; i++) {
				array1[i] = scan.nextInt();
			}
			System.out.println(Arrays.toString(mObj.shuffle(array, array1)));
			break;

		default:
			break;
		}
		scan.close();
	}

}
