package parkinglot;

public enum VehicleSize {
	Motorcycle, Compact, Large, Handicap, Electric
}
