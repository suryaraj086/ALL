package railwayticketbooking;

public class Berth {

	BerthType type;
	int seatNo;

	public BerthType getType() {
		return type;
	}

	public void setType(BerthType type) {
		this.type = type;
	}

	public int getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}

}
