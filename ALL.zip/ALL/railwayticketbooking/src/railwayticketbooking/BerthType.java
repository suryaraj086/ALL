package railwayticketbooking;

public enum BerthType {
	Upper, Middle, Lower, RAC, WAITING, SIDE_LOWER_BIRTH
}
