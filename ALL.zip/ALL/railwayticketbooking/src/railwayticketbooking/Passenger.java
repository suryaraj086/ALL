package railwayticketbooking;

public class Passenger {
	String status;
	String name;
	int age;
	int passengerid;
	int seatNo;

	public int getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getPassengerid() {
		return passengerid;
	}

	public void setPassengerid(int passengerid) {
		this.passengerid = passengerid;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return " status= " + status + ", name= " + name + ", age= " + age + ", ticket id= " + passengerid
				+ " seat number= " + seatNo + "\n";
	}

}
