package showroom;

public class Branch {
	String branchname;
	int seltosStock;
	int sonetStock;

	public String getBranchname() {
		return branchname;
	}

	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}

	public int getSeltosStock() {
		return seltosStock;
	}

	public void setSeltosStock(int seltosStock) {
		this.seltosStock = seltosStock;
	}

	public int getSonetStock() {
		return sonetStock;
	}

	public void setSonetStock(int sonetStock) {
		this.sonetStock = sonetStock;
	}

}
