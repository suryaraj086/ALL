package showroom;

import java.util.HashMap;
import java.util.Map;

public class CarShowRoom {

	String firstSold;
	String recentlySold;
	Map<String, HashMap<String, Branch>> branch = new HashMap<>();

	public String bookCar() {
		return firstSold;
	}

}
