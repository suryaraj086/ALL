package sort;

import java.util.*;
import java.util.Map.Entry;

class Compared implements Comparator<Map.Entry<Integer, Integer>> {
	public int compare(Entry<Integer, Integer> o1, Entry<Integer, Integer> o2) {
		if (o1.getValue() > o2.getValue())
			return -1;
		else if (o1.getValue() == o2.getValue()) {
			if (o1.getKey() > o2.getKey())
				return 1;
			else
				return -1;
		}
		return 1;
	}
}

class SortByFreq {
	static ArrayList<Integer> sortByFreq(int arr[], int n) {
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		for (int i = 0; i < n; i++) {
			int num = arr[i];
			if (map.containsKey(num)) {
				map.put(num, map.get(num) + 1);
			} else {
				map.put(num, 0);
			}
		}
		List<Map.Entry<Integer, Integer>> set = new ArrayList<>(map.entrySet());
		Collections.sort(set, new Compared());
		ArrayList<Integer> ans = new ArrayList<Integer>();
		for (int i = 0; i < map.size(); i++) {
			int count = set.get(i).getValue();
			while (count >= 0) {
				ans.add(set.get(i).getKey());
				count--;
			}
		}
		return ans;
	}

	public static void main(String[] args) {
		int[] arr = { 4, 6, 5, 4, 5 };
		System.out.print(sortByFreq(arr, arr.length));
	}

}