package virtualclass;

public enum Role {
	Faculty, Admin, Student
}
