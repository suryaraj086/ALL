package birds;
public class bird
{
public void fly()
{
System.out.print("AM FLYING");
}

}
