package child; 
import birds.*;
public class parrot
{
public void speak()
{
System.out.print("AM SPEAKING");
}

}
