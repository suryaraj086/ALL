package test;
import child.parrot;
import birds.bird;
public class TestRunner
{
public static void main(String args[])
{
bird d=new bird();
parrot p=new parrot();
d.fly();
p.speak();
}
}
