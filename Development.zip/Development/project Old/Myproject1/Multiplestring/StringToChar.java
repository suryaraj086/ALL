package task;
import java.util.*;

public class StringToChar
{

    private void strchecker(String strparam1) throws Exception
    {
        if (strparam1 == null || strparam1 == "") {
            try {
                throw new Exception("Invalid string");
            }
            catch(Exception e){
            }
        }
    }

    private void intchecker(String strparam1,int len) throws Exception
    {
        if(len>strparam1.length() || len<=0)
            try
            {
                throw new Exception("Invalid string or integer");
            }
            catch(Exception e){
            }
    }

    private void twostringchecker(String strparam1,String strparam2) throws Exception
    {
        if (strparam1 == null || strparam1 == ""|| strparam2 == null || strparam2 == "" || strparam2.length()>strparam1.length()) {
            try {
                throw new Exception("Invalid string");
            }
            catch(Exception e){
            }
        }
    }


    private void charchecker(char charac) throws Exception
    {
        if (Character.isWhitespace(charac)) {
            try {
                throw new Exception("Invalid");
            }
            catch(Exception e){
            }
        }
    }  private void checkstrarr(String strarr[]) throws Exception
{

    for (String s:strarr) {
        if(s==null)
        {
            try{

                throw new Exception("Invalid arr");
            }

            catch(Exception e){
            }
        }
    }
}


    public void task2(String strparam1) throws Exception{
        strchecker(strparam1);
        char[] ch = strparam1.toCharArray();     // or for loop can be used
        System.out.println("The char array is: ");
        for (int i = 0; i < ch.length; i++) {
            System.out.println(ch[i]);
        }

    }

    public char task3(String strparam1) throws Exception{
        strchecker(strparam1);
        int len = strparam1.length();
        char[] ch = strparam1.toCharArray();   // or for loop can be used
        System.out.println("The character is: " + ch[len - 2]);
        return ch[len - 2];
    }

    public int task4(String strparam1, char ch1) throws Exception{
        strchecker(strparam1);
        charchecker(ch1);
        char[] ch = strparam1.toCharArray(); // or for loop can be used
        int count = 0;
        for (int i = 0; i < strparam1.length(); i++) {
            if (strparam1.charAt(i) == ch1)
                count++;
        }
        System.out.println("Number of occurance is:" + count);
        return count;
    }

    public int task5(String strparam1, char ch1) throws Exception {
        strchecker(strparam1);
        charchecker(ch1);
        char[] ch = strparam1.toCharArray(); // or for loop can be used
        int pos = 0;
        for (int i = 0; i < strparam1.length(); i++) {
            if (strparam1.charAt(i) == ch1) {
                pos = i; //or array can be used
            }
        }
        System.out.println("The greatest number is:" + pos);
        return pos;
    }

    public String task6(String strparam1,int length) throws Exception {
        strchecker(strparam1);
        intchecker(strparam1,length);
        System.out.println("The last "+length+" character is: " + strparam1.substring(strparam1.length() - length));
        return strparam1.substring(strparam1.length() - length);
    }

    public String task7(String strparam1) throws Exception {
        strchecker(strparam1);
        System.out.println("The first three character is: " + strparam1.substring(0, 3));
        return strparam1.substring(0, 3);
    }

    public String task8(String strparam1, String strparam2) throws Exception  {
        twostringchecker(strparam1,strparam2);
        String strparam3 = strparam2 + strparam1.substring(strparam2.length());
        System.out.println("The string with first " + strparam2.length() + " changed character is: " + strparam3);
        return strparam3;
    }

    public boolean task9(String strparam1, String strparam2) throws Exception  {
        twostringchecker(strparam1,strparam2);
        System.out.println("Is the string starts with " + strparam2 + " : " + strparam1.startsWith(strparam2));
        return strparam1.startsWith(strparam2);
    }

    public boolean task10(String strparam1, String strparam2) throws Exception{
        System.out.println("Is the string ends with " + strparam2 + " : " + strparam1.endsWith(strparam2));
        return strparam1.endsWith(strparam2);
    }


    public String task11(String strparam1) throws Exception {
        strchecker(strparam1);
        System.out.println("The upper case is: " + strparam1.toUpperCase());
        return strparam1.toUpperCase();
    }

    public String task12(String strparam1) throws Exception {
        strchecker(strparam1);
        System.out.println("The lower case is: " + strparam1.toLowerCase());
        return strparam1.toLowerCase();
    }

    //string reverse
    public String task13(String strparam1) throws Exception {
        String strparam2 = "";
        strchecker(strparam1);
        for (int i = strparam1.length() - 1; i >= 0; i--) {
            strparam2 = strparam2 + strparam1.charAt(i);
        }
        System.out.print("The reverse string is: " + strparam2);
        return strparam2;
    }

    public void task14(String strparam1) throws Exception {
        strchecker(strparam1);
        System.out.println(strparam1);
    }

    public void task15(String str1) throws Exception {
        strchecker(str1);
        String noSpaceStr = str1.replaceAll(" ", ""); // using built in method
        System.out.println(noSpaceStr);

    }

    public void task16(String strparam2) throws Exception {
        strchecker(strparam2);
        String strarr[] = strparam2.split(" ");
        System.out.println("String : " + strparam2);
        System.out.print("String array : { ");
        for (int j = 0; j < strarr.length; j++) {
            System.out.print(strarr[j] + ", ");
        }
        System.out.print(" }");
    }

    public String task17(String strparam1[]) throws Exception  {
        checkstrarr(strparam1);
        String strparam3 = "";
        strparam3 = String.join("-", strparam1);
        System.out.println(strparam3);
        return strparam3;
    }


    public boolean task18(String strparam1, String strparam2) throws Exception {
        twostringchecker(strparam1,strparam2);
        System.out.println("Is the strings are same: " + strparam1.equals(strparam2));
        return strparam1.equals(strparam2);
    }

    public boolean task19(String strparam1, String strparam2) throws Exception {
        System.out.println("Is the strings are same: " + strparam1.equalsIgnoreCase(strparam2));
        return strparam1.equalsIgnoreCase(strparam2);
    }

    public String task20(String strparam1) throws Exception {
        strchecker(strparam1);
        System.out.println("The string is" + strparam1.trim());
        return strparam1.trim();
    }

    public static void main(String[] args) {
        StringToChar str = new StringToChar();
        Scanner scn1 = new Scanner(System.in);
        System.out.println("Enter the task number");
        int choice = 0;
        String std1 = "";
        try {
            choice = scn1.nextInt();
            if (choice == 0 || choice == 17) {
            }
            else
            {
                System.out.println("Enter your String");
                scn1.nextLine();
                std1 = scn1.nextLine();

            }
        }catch (Exception e) {
            System.out.print("invalid number");
        }
        if (std1 == null) {
            System.out.println("Enter a valid string");
        } else {
            switch (choice) {
                case 0:
                    break;
                case 1: {
                    for (String strs : args)
                        System.out.println(strs.length());
                    break;
                }
                case 2: {
                    try{
                        str.task2(std1);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Enter a valid string");
                    }

                    break;
                }
                case 3: {
                    try{
                        str.task3(std1);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Invalid string");
                    }
                    break;
                }
                case 4: {
                    System.out.println("Enter a character");
                    char ch1 = scn1.next().charAt(0);
                    try{
                        str.task4(std1, ch1);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Invalid string");
                    }
                    break;
                }
                case 5: {
                    System.out.println("Enter a character");
                    char ch2 = scn1.next().charAt(0);
                    try{
                        str.task5(std1, ch2);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Invalid string or character");
                    }

                    break;
                }
                case 6: {
                    System.out.println("Enter the length");
                    int num = scn1.nextInt();
                    try{
                        str.task6(std1,num);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Invalid string or number");
                    }
                    break;
                }
                case 7: {
                    try{
                        str.task7(std1);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Invalid string");
                    }
                    break;
                }
                case 8: {
                    System.out.println("Enter the string to replace the first characters");
                    String std2 = scn1.nextLine();
                    try
                    {
                        if (std2.equals("") || std2.equals("null") || std2.length() > std1.length()) {
                            System.out.println("Enter a valid string");
                        } else {
                            str.task8(std1, std2);
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println("Invalid string");
                    }
                    break;
                }
                case 9: {
                    System.out.println("Enter the string to check the first characters");
                    String std3 = scn1.nextLine();
                    try
                    {
                        if (std3.equals("") || std3.equals("null") || std3.length() > std1.length()) {
                            System.out.println("Enter a valid string");
                        } else {
                            str.task9(std1, std3);
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println("Invalid string");
                    }
                    break;
                }
                case 10: {
                    System.out.println("Enter the string to check the last characters");
                    String std4 = scn1.nextLine();
                    try
                    {
                        if (std4.equals("") || std4.equals("null") || std4.length() > std1.length()) {
                            System.out.println("Enter a valid string");
                        } else {
                            str.task10(std1, std4);
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println("Enter a valid string");
                    }
                    break;
                }
                case 11: {
                    try{
                        str.task11(std1);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Enter a valid string");
                    }
                    break;
                }
                case 12: {
                    try{
                        str.task12(std1);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Enter a valid string");
                    }
                    break;
                }
                case 13: {
                    try{
                        str.task13(std1);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Enter a valid string");
                    }
                    break;
                }
                case 14: {
                    try{
                        str.task14(std1);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Enter a valid string");
                    }
                    break;
                }
                case 15: {
                    try{
                        str.task15(std1);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Enter a valid string");
                    }
                    break;
                }
                case 16: {
                    try{
                        str.task16(std1);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Enter a valid string");
                    }

                    break;
                }
                case 17: {
                    System.out.println("Enter the length of string array");
                    int num = 0;
                    try{
                        num = scn1.nextInt();
                        scn1.nextLine();
                        String arr[] = new String[num];
                        System.out.println("Enter the string array");

                        for (int i = 0; i < num; i++) {
                            arr[i] = scn1.nextLine();
                        }
                        str.task17(arr);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Enter a valid string array or number");
                    }

                    break;
                }
                case 18: {
                    System.out.println("Enter the another string");
                    String std5 = scn1.nextLine();
                    try
                    {
                        if (std5.equals("") || std5.equals("null")) {
                            System.out.println("Enter a valid string");
                        } else {
                            str.task18(std1, std5);
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println("Enter a valid string");
                    }
                    break;
                }
                case 19: {
                    System.out.println("Enter the another string");
                    String std6 = scn1.nextLine();
                    try
                    {
                        if (std6.equals("") || std6.equals("null")) {
                            System.out.println("Enter a valid string");
                        } else {
                            str.task19(std1, std6);
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println("Enter a valid string");
                    }
                    break;
                }
                case 20: {
                    try
                    {
                        str.task20(std1);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Enter a valid string");
                    }
                    break;
                }
                default: {
                    System.out.println("Invalid Task Number");
                }
            }
        }
    }
}
