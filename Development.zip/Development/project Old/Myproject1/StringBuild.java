import java.util.*;
import java.lang.*;
import test.*;

public class StringBuild {

  StringTask obj=new StringTask();

    private void strChecker(String strParam1) throws Exception
    {
        if (strParam1 == null || strParam1 == "") {
            try {
                throw new Exception("Invalid string");
            }
            catch(Exception e){
            }
        }
    }


    public void task2(String strb1) throws Exception
    {
    obj.strChecker(strb1);
     StringBuilder strbuild= new StringBuilder();
     System.out.println("The length with no strings "+strbuild.length());
        strbuild.append(strb1);
               System.out.println("The length of the "+strb1.toString()+" string is "+strbuild.length());
    }

    public void task3(String strb1,String strb2[])
   {
       obj.strChecker(strb1);
     StringBuilder strbuild= new StringBuilder(strb1);
          System.out.println("The length of string "+strbuild.length());
          for(int i=0;i<strb2.length;i++)
          {
          strbuild.append("#");
          strbuild.append(strb2[i]);
          }     
          System.out.println("The multiple string is "+strbuild+" The length with multiple string is "+strbuild.length());
   
    }
  public void task4(String strb1,String strb2,String strb3)
   {
       obj.strChecker(strb1);
           obj.strChecker(strb2);
               obj.strChecker(strb3);
     int len=strb1.length();
     strb1=strb1.concat(" "+strb2);
     StringBuilder strbuild= new StringBuilder(strb1);
     System.out.println("The two strings are "+strbuild+" and the length is "+strbuild.length());
     strbuild.insert(len+1, strb3+" ");
     System.out.println("The multiple string is "+strbuild+" The length with multiple string is "+strbuild.length());
   
    }

    public void task5(String strb1,String strb2)
    {   
        obj.strChecker(strb1);
            obj.strChecker(strb2);
     int len=strb1.length();
     strb1=strb1.concat(" "+strb2);
     StringBuilder strbuild= new StringBuilder(strb1);
     System.out.println("The two strings are "+strbuild+" and the length is "+strbuild.length());
     strbuild.delete(0,len+1);
     System.out.println("The string after removal of first string is "+strbuild+" and the length of the string is "+strbuild.length());
      
    }

    public void task6(String strb1,String strb2,String strb3)
    {
        obj.strChecker(strb1);
            obj.strChecker(strb2);
                obj.strChecker(strb3);
            int len=strb1.length();
     strb1=strb1.concat(" "+strb2);
       strb1=strb1.concat(" "+strb3);
     StringBuilder strbuild= new StringBuilder(strb1);
     System.out.println("The three strings are "+strbuild+" and the length is "+strbuild.length());
     String noSpaceStr = strbuild.toString().replaceAll(" ", "-"); // using built in method
     System.out.println("The string after removal of first string is "+noSpaceStr+" and the length of the string is "+noSpaceStr.length());
  
    }

    public void task7(String strb1,String strb2,String strb3)
    {
        obj.strChecker(strb1);
            obj.strChecker(strb2);
                obj.strChecker(strb3);
                  int len=strb1.length();
     strb1=strb1.concat(" "+strb2);
       strb1=strb1.concat(" "+strb3);
     StringBuilder strbuild= new StringBuilder(strb1);
     System.out.println("The three strings are "+strbuild+" and the length is "+strbuild.length());
     strbuild.reverse(); // using built in method
     System.out.println("The string after string reverse is "+strbuild+" and the length of the string is "+strbuild.length());
  
    }

    public void task8(String strb1,int num,int num1) throws Exception
    {
        obj.strChecker(strb1);
     StringBuilder strbuild= new StringBuilder(strb1);
     if(strbuild.length()<10 ||num>num1 || num>strbuild.length() ||num1>strbuild.length())
     {
     throw new Exception("number should greater than 10");
     } // using built in method
     else
     {
          strbuild.delete(num,num1);
          System.out.println("The string after string deletion is "+strbuild+" and the length of the string is "+strbuild.length());
     }

  
    }
       public void task9(String strb1,String strb2,int num,int num1) throws Exception
    {
        obj.strChecker(strb1);
            obj.strChecker(strb2);
     StringBuilder strbuild= new StringBuilder(strb1);
     if(strbuild.length()<10 ||num>num1 || num>strbuild.length() ||num1>strbuild.length()||num1-num>strb2.length())
     {
     throw new Exception("String should greater than 10 or second number shold be greater than first ");
     } // using built in method
     else
     {
          strbuild.replace(num,num1,strb2);
          System.out.println("The string after string replcae is "+strbuild+" and the length of the string is "+strbuild.length());
     }

  
    }


    public void task10(String strb1,String strb2,String strb3)
    {
        int len=strb1.length();
     strb1=strb1.concat(" "+strb2);
       strb1=strb1.concat(" "+strb3);
     StringBuilder strbuild= new StringBuilder(strb1);
     System.out.println("The three strings are "+strbuild+" and the length is "+strbuild.length());
    String std= strbuild.toString().replaceAll(" ","#"); // using built in method

     int loc=std.indexOf("#");
          System.out.println("The string is "+std+" and the index of # is "+loc);
    }

    public void task11(String strb1,String strb2,String strb3)
      {
        int len=strb1.length();
     strb1=strb1.concat(" "+strb2);
       strb1=strb1.concat(" "+strb3);
     StringBuilder strbuild= new StringBuilder(strb1);
     System.out.println("The three strings are "+strbuild+" and the length is "+strbuild.length());
    String std= strbuild.toString().replaceAll(" ","#"); // using built in method

     int loc=std.lastIndexOf("#");
          System.out.println("The string is "+std+" and the index of # is "+loc);
    }

    public String task11(String s1)
    {
        System.out.println("The upper case is: "+s1.toUpperCase());
        return s1.toUpperCase();
    }

    public String task12(String s1)
    {
        System.out.println("The lower case is: "+s1.toLowerCase());
        return s1.toLowerCase();
    }

    //string reverse
    public String task13(String s1)
    {
        String s2="";
        for(int i=s1.length()-1;i>=0;i--)
        {
            s2=s2+s1.charAt(i);
        }
        System.out.print("The reverse string is: "+s2);
        return s2;
    }

    public void task14(String s1)
    {
        System.out.println(s1);
    }

    public void task15(String str1)
    {

        String noSpaceStr = str1.replaceAll(" ", ""); // using built in method  
        System.out.println(noSpaceStr);

    }

    public void task16(String s2)
    {
        String strarr[] = s2.split(" ");
        System.out.println("String : " + s2);
        System.out.print("String array : { ");
        for (int j = 0; j < strarr.length; j++) {
            System.out.print(strarr[j] + ", ");
        }
        System.out.print(" }");
    }

    public String task17(String s1[])
    {
         String s3="";
         s3=String.join("-",s1);
        System.out.println(s3);
        return s3;
    }


    public boolean task18(String s1,String s2)
    {
        System.out.println("Is the strings are same: "+s1.equals(s2));
        return s1.equals(s2);
    }

    public boolean task19(String s1,String s2)
    {
        System.out.println("Is the strings are same: "+s1.equalsIgnoreCase(s2));
        return s1.equalsIgnoreCase(s2);
    }
    
       public String task20(String s1)
    {
        System.out.println("The string is"+s1.trim());
        return s1.trim();
    }
        public static void main(String[] args) {
        StringBuild str=new StringBuild();
        Scanner scn1 = new Scanner(System.in);
        System.out.println("Enter the task number");
        int choice=0;
        String std1="";
        try{
            choice=scn1.nextInt();
            if(choice!=0||choice!=17)
            {
            System.out.println("Enter your String");
            scn1.nextLine();
            std1=scn1.nextLine();
            }
        }
        catch(Exception e)
        {
            System.out.print("invalid number");
        }
        if(std1.equals("") || std1.equals("null"))
        {
            System.out.println("Enter a valid string");
        }
        else
        {
            switch(choice)
            {
                case 0:
                    break;
                case 1:
                {
                    for(String strs:args)
                        System.out.println(strs.length());
                    break;
                }
                case 2:
                {
                try{
                    str.task2(std1);
                    }
                    catch(Exception e)
                    {
                    System.out.println("Enter a valid string");
                    }
                    break;
                }
                case 3:
                {
                System.out.println("Enter the length");
                int length=scn1.nextInt();
                scn1.nextLine();
                String std2[]=new String[length];
                for(int i=0;i<length;i++)
                {
                std2[i]=scn1.nextLine();
                 }
                    if(std2.equals("")||std2.equals("null"))
                    {
                        System.out.println("Enter a valid string");
                    }
                    else
                    {
                    str.task3(std1,std2);
                    }
                    break;
                }
                case 4:
                     {
                                     System.out.println("Enter the string");
                                     String std2=scn1.nextLine();
                                                    System.out.println("Enter the third string");
                String std3=scn1.nextLine();
                    if(std2==""||std2==null||std3==null||std3=="")
                    {
                        System.out.println("Enter a valid string");
                    }
                    else
                    {
                    str.task4(std1,std2,std3);
                    }
                    break;
                }
                case 5:
                {
                    System.out.println("Enter a character");
                    String strd3=scn1.nextLine();
                    
if(strd3==null||strd3=="")
                   {
                   System.out.println("end");
                   }
                   else
                   {
                        str.task5(std1,strd3);
                 }
                   
                    break;
                }
                case 6:
                {
                System.out.println("Enter the second string");
                String strd4=scn1.nextLine();
                System.out.println("Enter the third string");
                String strd5=scn1.nextLine();      
                str.task6(std1,strd4,strd5);
                break;
                }
                case 7:
                {
                System.out.println("Enter the second string");
                String strd6=scn1.nextLine();
                System.out.println("Enter the third string");
                String strd7=scn1.nextLine();      
                str.task7(std1,strd6,strd7);
                break;
                }
                case 8:
                {
                
                 int num=0;
                 int num1=0;
                 try
                 {
                  System.out.println("Enter the starting number");
                 num=scn1.nextInt();
                                   System.out.println("Enter the Ending number");
                 num1=scn1.nextInt();
                 if(num==0||num1==0||num1<num||num>std1.length()||num1>std1.length())
                 {
                 System.out.println("number should be greater than zero and second number should be greater than number one");
                 }
                    else
                    {
                        str.task8(std1,num,num1);
                    }
                    }
                    catch(Exception e){
                    System.out.println("num or string can't be empty or null");
                    }
                    break;
                    
                }
                case 9:
                {
                    System.out.println("Enter the second string");
                    String strd5=scn1.nextLine();
                                        System.out.println("Enter the third string");
                                        String strd6=scn1.nextLine();
                    if(strd5==""||strd5==null||strd6==""||strd6==null )
                    {
                        System.out.println("Enter a valid string");
                    }
                    else
                    {
                        str.task9(std1,strd5,strd6);
                    }
                    break;
                }
                case 10:
                   {
                    System.out.println("Enter the second string");
                    String strd7=scn1.nextLine();
                    System.out.println("Enter the third string");
                    String strd8=scn1.nextLine();
                    if(strd7==""||strd7==null||strd8==""||strd8==null )
                    {
                        System.out.println("Enter a valid string");
                    }
                    else
                    {
                        str.task10(std1,strd7,strd8);
                    }
                    break;
                }
                case 11:
                {
                    str.task11(std1);
                    break;
                }
                case 12:
                {
                    str.task12(std1);
                    break;
                }
                case 13:
                {
                    str.task13(std1);
                    break;
                }
                case 14:
                {
                    str.task14(std1);
                    break;
                }
                case 15:
                {
                    str.task15(std1);
                    break;
                }
                case 16:
                {
                    str.task16(std1);
                    break;
                }
                case 17:
                {
                System.out.println("Enter the length of string array");
                int num=scn1.nextInt();
                scn1.nextLine();
                String arr[]=new String[num];
                 for(int i=0;i<num;i++)
                 {
                 arr[i]=scn1.nextLine();
                 }
                    str.task17(arr);
                    break;
                }
                case 18:
                {
                    System.out.println("Enter the another string");
                    String std5=scn1.nextLine();
                    if(std5.equals("")||std5.equals("null"))
                    {
                        System.out.println("Enter a valid string");
                    }
                    else
                    {
                        str.task18(std1,std5);
                    }
                    break;
                }
                case 19:
                {
                    System.out.println("Enter the another string");
                    String std6=scn1.nextLine();
                    if(std6.equals("")||std6.equals("null"))
                    {
                        System.out.println("Enter a valid string");
                    }
                    else
                    {
                        str.task19(std1,std6);
                    }
                    break;
                }
                case 20:
                {
                    str.task20(std1);
                    break;
                }
                default:
                {
                    System.out.println("Invalid Task Number");
                }
            }
        }
    }
 
}
