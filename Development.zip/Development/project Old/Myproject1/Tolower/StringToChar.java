package task;
import java.util.*;
public class StringToChar {
public void task2()
{  
 Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
        char[] ch = s1.toCharArray();     // or for loop can be used   
        System.out.println("The char array is: ");  
        for (int i = 0; i < ch.length; i++) {  
            System.out.println(ch[i]);  
        }  
        }
public void task3()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
 int len=s1.length();
        char[] ch = s1.toCharArray();   // or for loop can be used  
         System.out.println("The character is: "+ch[len-2]);
      
    
}

public void task4()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
        char[] ch = s1.toCharArray(); // or for loop can be used   
 char ch1;
 System.out.println("Enter the character to find the occurance:");
 ch1=scn.next().charAt(0);
       int count = 0;
 
        for (int i=0; i<s1.length(); i++)
        {
         
            if (s1.charAt(i) == ch1)
            count++;
        }
    System.out.println("Number of occurance is:"+count);
}

public void task5()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
        char[] ch = s1.toCharArray(); // or for loop can be used   
 char ch1;
 System.out.println("Enter the character:");
 ch1=scn.next().charAt(0);
        ArrayList<Integer> array = new ArrayList<>();
        for (int i=0; i<s1.length(); i++)
        {
         
            if (s1.charAt(i) == ch1)
            {
           array.add(i);   //can be stored with integer to store only the last value
            }
        }
        int len=array.size();
    System.out.println("The greatest number is:"+array.get(len-1));
}

public void task6()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
 int len=s1.length();
System.out.println("The last five character is: " +s1.substring(len-5));
}
public void task7()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
System.out.println("The first three character is: " +s1.substring(0,3));
}
public void task8()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
  char[] ch = s1.toCharArray(); 
  ch[0]='x';
  ch[1]='y';
  ch[2]='z';
  s1 = String.valueOf(ch);
System.out.println("The string with first three changed character is: " +s1);
}

public void task9()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
  char[] ch = s1.toCharArray(); 
  if(ch[0]=='e'& ch[1]=='n' & ch[2]=='t')
  {
  System.out.println("First three letter matches e,n and t");
  }
  else{
System.out.println("The string is different");
}

}

public void task10()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
  char[] ch = s1.toCharArray(); 
  if(ch[ch.length-1]=='e'& ch[ch.length-2]=='l')
  {
  System.out.println("The last two letter matches with l and e");
  }
  else{
System.out.println("The string is different");
}

}

public void task11()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
System.out.println("The upper case is: "+s1.toUpperCase());
}

public void task12()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
System.out.println("The lower case is: "+s1.toLowerCase());
}

//string reverse
public void task13()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
 for(int i=s1.length;i<=0;i--)
 {
 System.out.println("The reverse string is: "+s1(i));
 }

}
public static void main(String[] args) {  
StringToChar str=new StringToChar();
    str.task13();
    }  
}  
