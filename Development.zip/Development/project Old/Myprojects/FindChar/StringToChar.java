package task3;
import java.util.*;
public class StringToChar {
public void task2()
{  
 Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
        char[] ch = s1.toCharArray();      
        System.out.println("The char array is: ");  
        for (int i = 0; i < ch.length; i++) {  
            System.out.println(ch[i]);  
        }  
        }
public void task3()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
 int len=s1.length();
        char[] ch = s1.toCharArray();   
         System.out.println("The character is: "+ch[len-2]);
      
    
}


public static void main(String[] args) {  
StringToChar str=new StringToChar();
    str.task3();
    }  
}  
