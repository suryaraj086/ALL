package task;
import java.util.*;
public class StringToChar {
public void task2()
{  
 Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
        char[] ch = s1.toCharArray();     // or for loop can be used   
        System.out.println("The char array is: ");  
        for (int i = 0; i < ch.length; i++) {  
            System.out.println(ch[i]);  
        }  
        }
public void task3()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
 int len=s1.length();
        char[] ch = s1.toCharArray();   // or for loop can be used  
         System.out.println("The character is: "+ch[len-2]);
      
    
}

public void task4()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
        char[] ch = s1.toCharArray(); // or for loop can be used   
 char ch1;
 System.out.println("Enter the character to find the occurance:");
 ch1=scn.next().charAt(0);
       int count = 0;
 
        for (int i=0; i<s1.length(); i++)
        {
         
            if (s1.charAt(i) == ch1)
            count++;
        }
    System.out.println("Number of occurance is:"+count);
}

public void task5()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
        char[] ch = s1.toCharArray(); // or for loop can be used   
 char ch1;
 System.out.println("Enter the character:");
 ch1=scn.next().charAt(0);
        ArrayList<Integer> array = new ArrayList<>();
        for (int i=0; i<s1.length(); i++)
        {
         
            if (s1.charAt(i) == ch1)
            {
           array.add(i);
            }
        }
        int len=array.size();
    System.out.println("The greatest number is:"+array.get(len-1));
}



public static void main(String[] args) {  
StringToChar str=new StringToChar();
    str.task5();
    }  
}  
