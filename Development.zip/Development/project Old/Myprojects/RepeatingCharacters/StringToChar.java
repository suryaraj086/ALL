package task;
import java.util.*;
public class StringToChar {
public void task2()
{  
 Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
        char[] ch = s1.toCharArray();     // or for loop can be used   
        System.out.println("The char array is: ");  
        for (int i = 0; i < ch.length; i++) {  
            System.out.println(ch[i]);  
        }  
        }
public void task3()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
 int len=s1.length();
        char[] ch = s1.toCharArray();   // or for loop can be used  
         System.out.println("The character is: "+ch[len-2]);
      
    
}

public void task4()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
        char[] ch = s1.toCharArray(); // or for loop can be used   
         Scanner scn1 = new Scanner(System.in);
 char ch1;
 System.out.println("Enter the character to find the occurance:");
 ch1=scn1.next().charAt(0);
       int count = 0;
 
        for (int i=0; i<s1.length(); i++)
        {
         
            if (s1.charAt(i) == ch1)
            count++;
        }
    System.out.println("Number of occurance is:"+count);
}

public void task4()
{
Scanner scn = new Scanner(System.in);
 String s1;
 System.out.println("Enter the string");
 s1=scn.nextLine();
        char[] ch = s1.toCharArray();   // or for loop can be used  by charAt[i]
         Scanner scn1 = new Scanner(System.in);
 char ch1;
 System.out.println("Enter the character to find the occurance:");
 ch1=scn1.next().charAt(0);
       int count = 0;
 
        for (int i=0; i<s1.length(); i++)
        {
         
            if (s1.charAt(i) == ch1)
            //If the character is found increment the count
            count++;
        }
    System.out.println("Number of occurance is:"+count);
}

public static void main(String[] args) {  
StringToChar str=new StringToChar();
    str.task4();
    }  
}  
