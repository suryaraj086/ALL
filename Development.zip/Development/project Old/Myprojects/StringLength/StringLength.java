import java.io.*;

public class StringLength
{
public static void main(String args[]) throws Exception
{
    InputStreamReader r=new InputStreamReader(System.in);    
    BufferedReader br=new BufferedReader(r);
    System.out.println("Enter the string:");  
        String name = br.readLine();
        System.out.println("The length of the string is "+name.length());
}
}
