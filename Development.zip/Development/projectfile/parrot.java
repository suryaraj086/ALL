
public class parrot
{

public static void main(String args[])
{
System.out.print("AM SPEAKING");
}


}
