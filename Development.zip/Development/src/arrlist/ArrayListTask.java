package arrlist;
import java.util.*;
import test.*;

public class ArrayListTask
{

StringTask strObj=new StringTask(); 

//List size

    public int arrSize(List inpArrList) throws Exception
    {
        arrListCheck(inpArrList);
        return inpArrList.size();
    }

//postion check

    public void positionCheckArr(List arrList,int fromIndex,int toIndex) throws Exception
    {
        arrListCheck(arrList);
        if(fromIndex>toIndex || fromIndex>arrSize(arrList)|| toIndex>arrSize(arrList))
        {
            throw new Exception("The numbers should not be greater than array or The second number should be less than first");
        }
    }

//Array index check    
    
    public void arrIndexCheck(List arrList,int index) throws Exception
    {
      arrListCheck(arrList);
      if(index>arrSize(arrList)||index<0)
        {
            throw new Exception("The position should not be greater than the array size");
        }
    }

//Array List null check

    public void arrListCheck(List inputList) throws Exception
    {
        if(inputList==null)
        {
            throw new Exception("The string can't be empty");
        }
    }
    


//1 = creating array list

    public List createArr()
    {
        List tempArrayList=new ArrayList();
        return tempArrayList;
    }

//2 = add 5 strings and //7th add 5 string and print using for loop //3 = add 5 integers //4 = add custom objects to array list

    public List arrToList(Object inpString[],List strList) throws Exception
    {
        arrListCheck(strList);
        strList.addAll(Arrays.asList(inpString));
        return strList;
    }


// 5 = add integer,string and custom object


    public List addIntStr(Object inputString[],Object inputObject[],Object inputInteger[],List strArrayList) throws Exception
    {
        arrListCheck(strArrayList);
       // strObj.checkStrArr(inputString);
        strArrayList.addAll(Arrays.asList(inputString));
        strArrayList.addAll(Arrays.asList(inputObject));
        strArrayList.addAll(Arrays.asList(inputInteger));
        return strArrayList;
    }

//6 = index of already added string 

    public int indexOfString(List inputList,String inputString) throws Exception
    {
        strObj.strChecker(inputString);
        arrListCheck(inputList);
        int pos=inputList.indexOf(inputString);
        return pos;
    }


//8 = string at a given index

    public String strAtIndex(List arrList,int index) throws Exception
    {
        arrIndexCheck(arrList,index);
        String pos = arrList.get(index).toString();
        return pos;
    }

//9 = first and last index of duplicate string 

    public int lastIndexOfString(List inputList,String inputString)throws Exception
    {
        strObj.strChecker(inputString);
        arrListCheck(inputList);
        int pos=inputList.lastIndexOf(inputString);
        return pos;
    }

//10 = add element at specific index

    public List addElementIndex(List inpArr,String input,int index) throws Exception
    {
        strObj.strChecker(input);
        arrIndexCheck(inpArr,index);
        arrListCheck(inpArr);
        inpArr.add(index,input);
        return inpArr;
    }


//11 = copy elements from position 3 to 8

    public List copyPos(List inpArr,int fromIndex,int toIndex) throws Exception
    {
        positionCheckArr(inpArr,fromIndex,toIndex);
        List str=(List)inpArr.subList(fromIndex, toIndex);
        return str;
    }

//12 = create (third List) using the above two List & 13 = create (third List) using the above two List & second ahead of first List

    public List addListFirst(List arrList,List inputList) throws Exception
    {
        arrListCheck(arrList);
        arrListCheck(inputList);
        arrList.addAll(inputList);
        return arrList;
    }


//14 = remove a element

    public List removePosition(double decimalToRemove,List decArr) throws Exception
    {
        arrListCheck(decArr);
        decArr.remove(decimalToRemove);
        return decArr;
    }

// 15 = remove element in a position of List

    public List removePosition(int position,List decArr) throws Exception
    {
        arrIndexCheck(decArr,position);
        decArr.remove(position);
        return decArr;
    }

//17 = remove element from List 1 that are in List 2  

    public List removeArrList(List arrList,List inpArrList) throws Exception
    {
        arrListCheck(arrList);
        arrListCheck(inpArrList);
        arrList.removeAll(inpArrList);
        return arrList;
    }


//18 = remove element from List 1 that are not in List 2

    public List removeNotArrList(List arrList,List strArr) throws Exception
    {
        arrListCheck(arrList);
        arrListCheck(strArr);
        arrList.retainAll(strArr);
        return arrList;
    }

//19 = Remove all long values from array list

    public List removeAllLong(List longArr) throws Exception
    {
        arrListCheck(longArr);
        longArr.clear();
        return longArr;
    }

//20 = string is present or not in the list

    public boolean stringPresentCheck(List arrList,String inputString) throws Exception
    {
        strObj.strChecker(inputString);
        arrListCheck(arrList);
        boolean bool=arrList.contains(inputString);
        return bool;
    }
}
