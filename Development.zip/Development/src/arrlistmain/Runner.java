package arrlistmain;
import test.*;
import arrlist.*;
import java.util.*;

public class Runner
{

    public static void main(String[] args)
    {
        StringTask strObj = new StringTask();
        ArrayListTask arObj=new ArrayListTask();
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the task number");
        int choice = 0;
        String inputString="";
        try
        {
            choice = scan.nextInt();
            scan.nextLine();
        }
        catch (Exception e)
        {
            System.out.print("Enter numbers only");
        }

        switch (choice){

            case 1:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    System.out.println("The size of array is "+arObj.arrSize(arrListObj));
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage());
                }
                break;
            }
            case 2:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    scan.nextLine();
                    Object[] strArr=new Object[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArr[iterate]=scan.nextLine();
                    }
                    arrListObj=arObj.arrToList(strArr,arrListObj);
                    System.out.println("The array list is "+arrListObj+ " and the size is "+arObj.arrSize(arrListObj));
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+"The length of array should be number");
                }
                break;
            }
            case 3:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    scan.nextLine();
                    Object intArr[]=new Object[length];
                    System.out.println("Enter the integer array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        intArr[iterate]=scan.nextInt();
                    }
                    arrListObj=arObj.arrToList(intArr,arrListObj);
                    System.out.println("The array list is "+arrListObj+ " and the size is "+arObj.arrSize(arrListObj));
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length of array should be number and array should contain integer");
                }
                break;
            }
            case 4:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    Object objArr[]=new Object[2];
                    objArr[0]=new Object();
                    objArr[1]=new Object();
                    arrListObj=arObj.arrToList(objArr,arrListObj);
                    System.out.println("The array list is "+arrListObj+ " and the size is "+arObj.arrSize(arrListObj));
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+"The length of array should be number");
                }
                break;
            }
            case 5:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    System.out.println("Enter the length of string");
                    int length=scan.nextInt();
                    scan.nextLine();
                    Object strArr[]=new Object[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArr[iterate]=scan.nextLine();
                    }

                    Object objArr[]=new Object[2];
                    objArr[0]=new Object();
                    objArr[1]=new Object();
                    System.out.println("Enter the length of int");
                    length=scan.nextInt();
                    scan.nextLine();
                    Object intArr[]=new Object[length];
                    System.out.println("Enter the integer array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        intArr[iterate]=scan.nextInt();
                    }

                    arrListObj=arObj.addIntStr(strArr,objArr,intArr,arrListObj);
                    System.out.println("The array list is "+arrListObj+ " and the size is "+arObj.arrSize(arrListObj));
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length should be number and integer array should contain numbers");
                }
                break;
            }
            case 6:
            {
                try
                {

                    List arrListObj=arObj.createArr();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    scan.nextLine();
                    String strArr[]=new String[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArr[iterate]=scan.nextLine();
                    }
                    System.out.println("Enter your already added string");
                    inputString = scan.nextLine();
                    arrListObj=arObj.arrToList(strArr,arrListObj);
                    int postion=arObj.indexOfString(arrListObj,inputString);
                    System.out.println("The position of given string is "+postion);
                    System.out.println("The array list is "+arrListObj+ " and the size is "+arObj.arrSize(arrListObj));
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length should be number");
                }
                break;
            }
            case 7:
            {

                try
                {
                    List arrListObj=arObj.createArr();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    scan.nextLine();
                    String strArr[]=new String[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArr[iterate]=scan.nextLine();
                    }
                    arrListObj=arObj.arrToList(strArr,arrListObj);
                    int arrLength=arObj.arrSize(arrListObj);
                    System.out.println("The array list printed using for loop");
                    for (int i = 0; i < arrLength; i++)
                    {
                        System.out.println(arrListObj.get(i));
                    }
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The postion and length should be numbers");
                }
                break;
            }
            case 8:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    scan.nextLine();
                    String strArr[]=new String[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArr[iterate]=scan.nextLine();
                    }
                    arrListObj=arObj.arrToList(strArr,arrListObj);
                    System.out.println("Enter the index");
                    int index=scan.nextInt();
                    String strAtPos = arObj.strAtIndex(arrListObj,index);
                    System.out.println("string at a given index "+strAtPos);
                    System.out.println("The array list is "+arrListObj+ " and the size is "+arObj.arrSize(arrListObj));

                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The postion and length should be numbers");
                }
                break;
            }
            case 9:
            {

                try
                {
                    List arrListObj=arObj.createArr();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    scan.nextLine();
                    String strArr[]=new String[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArr[iterate]=scan.nextLine();
                    }
                    arrListObj=arObj.arrToList(strArr,arrListObj);
                    System.out.println("Enter your already added duplicate string");
                    inputString = scan.nextLine();
                    int postion=arObj.indexOfString(arrListObj,inputString);
                    int secondPos=arObj.lastIndexOfString(arrListObj,inputString);
                    System.out.println("The position of given string in a array list is "+postion+" & "+secondPos);
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length of array should be number");
                }
                break;
            }
            case 10:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    scan.nextLine();
                    String strArr[]=new String[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArr[iterate]=scan.nextLine();
                    }
                    System.out.println("Enter the string to insert");
                    inputString = scan.nextLine();
                    System.out.println("Enter the index to insert");
                    int index=scan.nextInt();
                    scan.nextLine();
                    arrListObj = arObj.arrToList(strArr,arrListObj);
                    arrListObj = arObj.addElementIndex(arrListObj,inputString,index);
                    System.out.println("The array list after insert"+arrListObj);
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" and the length of array or index should be number");
                }
                break;
            }
            case 11:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    scan.nextLine();
                    String strArr[]=new String[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArr[iterate]=scan.nextLine();
                    }
                    System.out.println("Enter the first index");
                    int fromIndex=scan.nextInt();
                    scan.nextLine();
                    System.out.println("Enter the second index to create the new array");
                    int toIndex=scan.nextInt();
                    scan.nextLine();
                    arrListObj = arObj.arrToList(strArr,arrListObj);
                    arrListObj = arObj.copyPos(arrListObj,fromIndex,toIndex);
                    System.out.println("The array list after creation of new array with given position is "+arrListObj);
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length of array should be number");
                }
                break;
            }
            case 12:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    List arrListObj1=arObj.createArr();
                    System.out.println("Enter the length of first array");
                    int length=scan.nextInt();
                    scan.nextLine();
                    String strArr[]=new String[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArr[iterate]=scan.nextLine();
                    }
                    System.out.println("Enter the length of second array");
                    length=scan.nextInt();
                    scan.nextLine();
                    String strArrTwo[]=new String[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArrTwo[iterate]=scan.nextLine();
                    }

                    arrListObj = arObj.arrToList(strArr,arrListObj);
                    arrListObj1 = arObj.arrToList(strArrTwo,arrListObj1);
                    arrListObj = arObj.addListFirst(arrListObj,arrListObj1);
                    System.out.println("The new array list using two array list is "+arrListObj);
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length of array should be number");
                }
                break;
            }
            case 13:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    List arrListObj1=arObj.createArr();
                    System.out.println("Enter the length of first array");
                    int length=scan.nextInt();
                    scan.nextLine();
                    String strArr[]=new String[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArr[iterate]=scan.nextLine();
                    }
                    System.out.println("Enter the length of second array");
                    length=scan.nextInt();
                    scan.nextLine();
                    String strArrTwo[]=new String[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArrTwo[iterate]=scan.nextLine();
                    }

                    arrListObj = arObj.arrToList(strArr,arrListObj);
                    arrListObj1 = arObj.arrToList(strArrTwo,arrListObj1);
                    arrListObj = arObj.addListFirst(arrListObj1,arrListObj);
                    System.out.println("The new array list using two array list is "+arrListObj);
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length of array should be number");
                }
                break;
            }
            case 14:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    List arrListObj1=arObj.createArr();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    scan.nextLine();
                    Object doubleArr[]=new Object[length];
                    System.out.println("Enter the double array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        doubleArr[iterate]=scan.nextDouble();
                    }
                    arrListObj = arObj.arrToList(doubleArr,arrListObj);
                    System.out.println("Enter the decimal to remove");
                    double decimal=scan.nextDouble();
                    scan.nextLine();
                    arrListObj = arObj.removePosition(decimal,arrListObj);
                    System.out.println("The array list after the removal of decimal is "+arrListObj);
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length of array should be number and decimal shoule be number");
                }
                break;
            }
            case 15:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    List arrListObj1=arObj.createArr();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    scan.nextLine();
                    Object doubleArr[]=new Object[length];
                    System.out.println("Enter the double array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        doubleArr[iterate]=scan.nextDouble();
                    }
                    arrListObj = arObj.arrToList(doubleArr,arrListObj);
                    System.out.println("Enter the position to remove");
                    int position=scan.nextInt();
                    scan.nextLine();
                    arrListObj = arObj.removePosition(position,arrListObj);
                    System.out.println("The array list after the removal of decimal is "+arrListObj);
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length of array should be number or double should be number");
                }
                break;
            }
            case 16:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    List arrListObj1=arObj.createArr();
                    System.out.println("Enter the length of first array list");
                    int length=scan.nextInt();
                    scan.nextLine();
                    String strArr[]=new String[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArr[iterate]=scan.nextLine();
                    }
                    System.out.println("Enter the length of second array list");
                    length=scan.nextInt();
                    scan.nextLine();
                    String strArrTwo[]=new String[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArrTwo[iterate]=scan.nextLine();
                    }
                    arrListObj = arObj.arrToList(strArr,arrListObj);
                    arrListObj1 = arObj.arrToList(strArrTwo,arrListObj1);
                    arrListObj = arObj.removeArrList(arrListObj,arrListObj1);
                    System.out.println("The array list after removal of similar elements "+arrListObj);
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length of array should be number or double should be number");
                }
                break;
            }
            case 17:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    List arrListObj1=arObj.createArr();
                    System.out.println("Enter the length of first array list");
                    int length=scan.nextInt();
                    scan.nextLine();
                    String strArr[]=new String[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArr[iterate]=scan.nextLine();
                    }
                    System.out.println("Enter the length of second array list");
                    length=scan.nextInt();
                    scan.nextLine();
                    String strArrTwo[]=new String[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArrTwo[iterate]=scan.nextLine();
                    }
                    arrListObj = arObj.arrToList(strArr,arrListObj);
                    arrListObj1 = arObj.arrToList(strArrTwo,arrListObj1);
                    arrListObj = arObj.removeNotArrList(arrListObj,arrListObj1);
                    System.out.println("The array list after removal of non similar elements "+arrListObj+" and the size is "+arObj.arrSize(arrListObj));
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length of array should be number");
                }
                break;
            }
            case 18:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    System.out.println("Enter the length of long");
                    int length=scan.nextInt();
                    scan.nextLine();
                    Object longArr[]=new Object[length];
                    System.out.println("Enter the long array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        longArr[iterate]=scan.nextLong();
                    }
                    arrListObj = arObj.arrToList(longArr,arrListObj);
                    arrListObj = arObj.removeAllLong(arrListObj);
                    System.out.println("The array list after removal of long values"+arrListObj);
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length of array should be number");
                }
                break;
            }
            case 19:
            {
                try
                {
                    List arrListObj=arObj.createArr();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    scan.nextLine();
                    String strArr[]=new String[length];
                    System.out.println("Enter the string array");
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        strArr[iterate]=scan.nextLine();
                    }
                    System.out.println("Enter the string to check whether it is present or not");
                    inputString = scan.nextLine();
                    arrListObj = arObj.arrToList(strArr,arrListObj);
                    boolean bool = arObj.stringPresentCheck(arrListObj,inputString);
                    System.out.println("Is the string present in the array list "+bool);
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length of array should be number");
                }
                break;
            }

            default:
            {
                System.out.println("Enter Task Number between 1 to 19");
            }
        }
        scan.close();
    }
}
