package hashtask;
import java.util.*;
import myexception.*;

public class HashMapTask
{

//hash map size

    public int hashSize(Map<Object,Object> hashInput) throws CustomException
    {
        mapNullCheck(hashInput);
        return hashInput.size();
    }

//hashmap null check

    public void mapNullCheck(Map<Object,Object> hashMapToCheck) throws CustomException
    {
        if(hashMapToCheck == null)
        {
            throw new CustomException("The hash map can't be null");
        }
    }

//1 = creating a hashmap

    public Map<Object,Object> createMap()
    {
        Map<Object,Object>  inputHashMap=new HashMap<Object,Object> ();
        return inputHashMap;
    }

//2 = hashmap with three string key and value //3 //4 //5 //6 //7 //19

    public Map<Object, Object> mapInsert(Map<Object, Object> inputHash,Object inputKeyObject,Object inputValObject) throws CustomException
    {
        mapNullCheck(inputHash);
        inputHash.put(inputKeyObject,inputValObject);
        return inputHash;
    }

//8 = to check a key exists

    public boolean keyCheck(Map<Object, Object> inputHash,Object keyToBeChecked) throws CustomException
    {
        mapNullCheck(inputHash);
        return inputHash.containsKey(keyToBeChecked);
    }

//9 = to check a value exists

    public boolean valueCheck(Map<Object, Object> inputHash,Object valueToBeChecked) throws CustomException
    {
        mapNullCheck(inputHash);
        return inputHash.containsValue(valueToBeChecked);
    }

//11 = get the value using existing key & 12 get the value using non existing key

    public Object getVal(Map<Object, Object> inputHash,Object inputKey) throws CustomException
    {
        mapNullCheck(inputHash);
        return inputHash.get(inputKey);
    }

//13 = return “Zoho” as a value for a given non existing key 

    public Object getValNonExisting(Map<Object, Object> inputHash,Object inputKey,Object inputValue) throws CustomException
    {
        mapNullCheck(inputHash);
        return inputHash.getOrDefault(inputKey,inputValue);
    }

//14 = remove existing key in the hashmap

    public Map<Object, Object> removeKey(Map<Object, Object> inputHash,Object inputKey) throws CustomException
    {
        mapNullCheck(inputHash);
        inputHash.remove(inputKey);
        return inputHash;
    }

//15 = remove key if matches with the value

    public Map<Object, Object> removeKeyValue(Map<Object, Object> inputHash,Object inputKey,Object inputValue) throws CustomException
    {
        mapNullCheck(inputHash);
        inputHash.remove(inputKey,inputValue);
        return inputHash;
    }

//16 = replace the value of an existing key in a HashMap

    public Map<Object, Object> replaceKey(Map<Object, Object> inputHash,Object inpKey,Object newValue) throws CustomException
    {
        mapNullCheck(inputHash);
        inputHash.replace(inpKey,newValue);
        return inputHash;
    }

//17 = replace the value of an existing key only if it’s value matches

    public Map<Object, Object> replaceKeyByValue(Map<Object, Object> inputHash,Object inpKey,Object oldValue,Object newValue) throws CustomException
    {

        mapNullCheck(inputHash);
        inputHash.replace(inpKey,oldValue,newValue);
        return inputHash;
    }

//18 = transfer all the keys & values of a HashMap to another HashMap

    public Map<Object, Object> copyMap(Map<Object, Object> inpHash,Map<Object, Object> copiedMap) throws CustomException
    {
        mapNullCheck(inpHash);
        copiedMap.putAll(inpHash);
        return copiedMap;
    }

//20 =  remove all entries in a HashMap

    public Map<Object, Object> removeAllMap(Map<Object, Object> inputHash) throws CustomException
    {
        mapNullCheck(inputHash);
        inputHash.clear();
        return inputHash;
    }

}
