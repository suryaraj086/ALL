package hashtaskmain;
import test.*;
import hashtask.*;
import java.util.*;
import myexception.*;

public class Runner
{
    static StringTask strObj = new StringTask();
    static HashMapTask hashObj=new HashMapTask();
    Scanner scan = new Scanner(System.in);
    static Object strKeyArr;
    static Object strValueArr;

    public Map<Object,Object> caseMethod() throws CustomException
    {
        Map <Object,Object>  hashMapObj=hashObj.createMap();
        System.out.println("Enter the length");
        int length=scan.nextInt();
        scan.nextLine();
        for(int iterate=0;iterate<length;iterate++)
        {
            System.out.println("Enter the key: ");
            strKeyArr=scan.nextLine();
            System.out.println("Enter the value: ");
            strValueArr=scan.nextLine();
            hashMapObj = hashObj.mapInsert(hashMapObj,strKeyArr,strValueArr);
        }
        System.out.println("The hashmap is "+hashMapObj+ " and the size is "+hashObj.hashSize(hashMapObj));
        return hashMapObj;
    }

    public static void main(String[] args) throws CustomException
    {
        System.out.println("Enter the task number");
        Scanner scan = new Scanner(System.in);
        int choice = 0;
        String inputString="";
        Runner run=new Runner();
        try
        {
            choice = scan.nextInt();
            scan.nextLine();
        }
        catch (Exception e)
        {
            System.out.print("Enter numbers only");
        }


        switch (choice){

            case 1:
            {
                try
                {
                    Map <Object,Object>  hashMapObj=hashObj.createMap();
                    System.out.println("The size of hashmap is "+hashObj.hashSize(hashMapObj));
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage());
                }
                break;
            }
            case 2:
            {
                run.caseMethod();
                break;
            }
            case 3:
            {
                try
                {
                    Map <Object,Object>  hashMapObj=hashObj.createMap();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    scan.nextLine();
                    Object strKeyArr;
                    Object strValueArr;
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        System.out.println("Enter the key: ");
                        strKeyArr=scan.nextInt();
                        System.out.println("Enter the value: ");
                        strValueArr=scan.nextInt();
                        hashMapObj = hashObj.mapInsert(hashMapObj,strKeyArr,strValueArr);
                    }
                    System.out.println("The hashmap is "+hashMapObj+ " and the size is "+hashObj.hashSize(hashMapObj));
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length of array should be number and array should contain integer");
                }
                break;
            }
            case 4:
            {
                try
                {
                    Map <Object,Object>  hashMapObj=hashObj.createMap();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    scan.nextLine();
                    Object strKeyArr;
                    Object strValueArr;
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        System.out.println("Enter the key: ");
                        strKeyArr=scan.nextLine();
                        System.out.println("Enter the value: ");
                        strValueArr=scan.nextInt();
                        scan.nextLine();
                        hashMapObj = hashObj.mapInsert(hashMapObj,strKeyArr,strValueArr);
                    }
                    System.out.println("The hashmap is "+hashMapObj+ " and the size is "+hashObj.hashSize(hashMapObj));
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+"The length of array should be number");
                }
                break;
            }
            case 5:
            {
                try
                {
                    Map <Object,Object>  hashMapObj=hashObj.createMap();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    scan.nextLine();
                    Object strKeyArr;
                    Object strValueArr;
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        System.out.println("Enter the key: ");
                        strKeyArr=scan.nextLine();
                        strValueArr=new Object();
                        hashMapObj = hashObj.mapInsert(hashMapObj,strKeyArr,strValueArr);
                    }
                    System.out.println("The hashmap is "+hashMapObj+ " and the size is "+hashObj.hashSize(hashMapObj));
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length should be number and integer array should contain numbers");
                }
                break;
            }
            case 6:
            {
                try
                {
                    Map <Object,Object>  hashMapObj=hashObj.createMap();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    System.out.println("Enter position to insert null");
                    int nullpos=scan.nextInt();
                    scan.nextLine();
                    Object strKeyArr="";
                    Object strValueArr;
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        if(iterate!=nullpos)
                        {
                            System.out.println("Enter the key: ");
                            strKeyArr=scan.nextLine();
                        }
                        System.out.println("Enter the value: ");
                        strValueArr=scan.nextLine();
                        while(iterate==nullpos)
                        {
                            strKeyArr=null;
                            hashMapObj = hashObj.mapInsert(hashMapObj,strKeyArr,strValueArr);
                            break;
                        }
                        hashMapObj = hashObj.mapInsert(hashMapObj,strKeyArr,strValueArr);
                    }
                    System.out.println("The hashmap is "+hashMapObj+ " and the size is "+hashObj.hashSize(hashMapObj));
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length should be number");
                }
                break;
            }
            case 7:
            {

                try
                {
                    Map <Object,Object>  hashMapObj=hashObj.createMap();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    System.out.println("Enter position to insert null");
                    int nullpos=scan.nextInt();
                    scan.nextLine();
                    Object strKeyArr="";
                    Object strValueArr="";
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        System.out.println("Enter the key: ");
                        strKeyArr=scan.nextLine();
                        if(iterate!=nullpos)
                        {
                            System.out.println("Enter the value: ");
                            strValueArr=scan.nextLine();
                        }
                        while(iterate==nullpos)
                        {
                            strValueArr=null;
                            hashMapObj = hashObj.mapInsert(hashMapObj,strKeyArr,strValueArr);
                            break;
                        }
                        hashMapObj = hashObj.mapInsert(hashMapObj,strKeyArr,strValueArr);
                    }
                    System.out.println("The hashmap is "+hashMapObj+ " and the size is "+hashObj.hashSize(hashMapObj));
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The postion and length should be numbers");
                }
                break;
            }
            case 8:
            {       Map <Object,Object>  hashMapObj=hashObj.createMap();
                hashMapObj=run.caseMethod();
                System.out.println("Enter the key to be checked: ");
                String strKey=scan.nextLine();
                boolean bool=hashObj.keyCheck(hashMapObj,strKey);
                System.out.println("Is the key exists in hashmap "+bool);

                break;
            }
            case 9:
            {

                Map <Object,Object>  hashMapObj=hashObj.createMap();
                hashMapObj=run.caseMethod();
                System.out.println("Enter the value to be checked: ");
                String strValue=scan.nextLine();
                boolean bool=hashObj.valueCheck(hashMapObj,strValue);
                System.out.println("Is the value exists in hashmap "+bool);

                break;
            }
            case 10:
            {
                try
                {
                    Map <Object,Object>  hashMapObj=hashObj.createMap();
                    Map <Object,Object>  hashMapObjNew=hashObj.createMap();
                    hashMapObj=run.caseMethod();
                    hashMapObjNew=run.caseMethod();
                    hashObj.copyMap(hashMapObj,hashMapObjNew);
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" and the length of array or index should be number");
                }
                break;
            }
            case 11:
            {
                Map <Object,Object>  hashMapObj=hashObj.createMap();
                hashMapObj=run.caseMethod();
                System.out.println("Enter the key to get the value: ");
                strKeyArr=scan.nextLine();
                Object subOutput=hashObj.getVal(hashMapObj,strKeyArr);
                System.out.println("Enter the value of the existing key is : "+subOutput);

                break;
            }
            case 12:
            {

                Map <Object,Object>  hashMapObj=hashObj.createMap();
                hashMapObj=run.caseMethod();
                System.out.println("Enter the non existing key to get the value: ");
                strKeyArr=scan.nextLine();
                Object s=hashObj.getVal(hashMapObj,strKeyArr);
                System.out.println("Enter the value of the non existing key is : "+s);

                break;
            }
            case 13:
            {
                Map <Object,Object>  hashMapObj=hashObj.createMap();
                hashMapObj=run.caseMethod();
                System.out.println("Enter the non exising : ");
                strKeyArr=scan.nextLine();
                System.out.println("Enter the value to print for non existing key : ");
                strValueArr=scan.nextLine();
                Object strInp=hashObj.getValNonExisting(hashMapObj,strKeyArr,strValueArr);
                System.out.println("the value of the non existing key is : "+strInp);

                break;
            }
            case 14:
            {
                Map <Object,Object>  hashMapObj=hashObj.createMap();
                hashMapObj=run.caseMethod();
                System.out.println("Enter the key to remove: ");
                strKeyArr=scan.nextLine();
                hashMapObj =hashObj.removeKey(hashMapObj,strKeyArr);
                System.out.println("The map is : "+hashMapObj);

                break;
            }
            case 15:
            {
                Map <Object,Object>  hashMapObj=hashObj.createMap();
                hashMapObj=run.caseMethod();
                System.out.println("Enter the key to remove: ");
                strKeyArr=scan.nextLine();
                System.out.println("Enter the value that matches the key: ");
                strValueArr=scan.nextLine();
                hashMapObj =hashObj.removeKeyValue(hashMapObj,strKeyArr,strValueArr);
                System.out.println("The map is : "+hashMapObj);
                break;
            }
            case 16:
            {
                Map <Object,Object>  hashMapObj=hashObj.createMap();
                hashMapObj=run.caseMethod();
                System.out.println("Enter the key to replace: ");
                strKeyArr=scan.nextLine();
                System.out.println("Enter the value tto be replaced: ");
                strValueArr=scan.nextLine();
                hashMapObj =hashObj.replaceKey(hashMapObj,strKeyArr,strValueArr);
                System.out.println("The map is : "+hashMapObj);
                break;
            }
            case 17:
            {

                Map <Object,Object>  hashMapObj=hashObj.createMap();
                hashMapObj=run.caseMethod();
                System.out.println("Enter the key to remove: ");
                strKeyArr=scan.nextLine();
                System.out.println("Enter the value that matches the key: ");
                Object strOldValue=scan.nextLine();
                System.out.println("Enter the new value: ");
                Object strNewVal=scan.nextLine();
                hashMapObj =hashObj.replaceKeyByValue(hashMapObj,strKeyArr,strOldValue,strNewVal);
                System.out.println("The map is : "+hashMapObj);

                break;
            }
            case 18:
            {

                Map <Object,Object>  hashMapObj=hashObj.createMap();
                Map <Object,Object>  hashMapObjNew=hashObj.createMap();
                hashMapObj=run.caseMethod();
                hashMapObjNew=hashObj.copyMap(hashMapObj,hashMapObjNew);
                System.out.println("The copied hashmap is "+hashMapObjNew+ " and the size is "+hashObj.hashSize(hashMapObjNew));

                break;
            }
            case 19:
            {
                try
                {
                    Map <Object,Object>  hashMapObj=hashObj.createMap();
                    Map <Object,Object>  hashMapObjNew=hashObj.createMap();
                    System.out.println("Enter the length");
                    int length=scan.nextInt();
                    scan.nextLine();
                    Object strKeyArr;
                    Object strValueArr;
                    for(int iterate=0;iterate<length;iterate++)
                    {
                        System.out.println("Enter the key: ");
                        strKeyArr=scan.nextLine();
                        System.out.println("Enter the value: ");
                        strValueArr=scan.nextLine();
                        hashMapObj = hashObj.mapInsert(hashMapObj,strKeyArr,strValueArr);
                    }
                    Iterator it = hashMapObj.entrySet().iterator();
                    while(it.hasNext())
                    {
                        System.out.print(it.next());
                    }
                }
                catch(Exception e)
                {
                    System.out.println(e.getMessage()+" The length of array should be number");
                }
                break;
            }


            case 20:
            {
                Map <Object,Object>  hashMapObj=hashObj.createMap();
                hashMapObj=run.caseMethod();
                hashMapObj = hashObj.removeAllMap(hashMapObj);
                System.out.println("The hashmap is "+hashMapObj+ " and the size is "+hashObj.hashSize(hashMapObj));

                break;
            }

            default:
            {
                System.out.println("Enter Task Number between 1 to 19");
            }
        }
        scan.close();
    }
}
