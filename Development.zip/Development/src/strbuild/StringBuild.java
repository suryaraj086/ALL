package strbuild;
import java.util.*;
import test.*;

public class StringBuild
{

    StringTask obj=new StringTask();

    public int getLength(StringBuilder srbuild)
    {
        return srbuild.length();
    }

    public StringBuilder createSB()
    {
        StringBuilder strngBuild=new StringBuilder();
        return strngBuild;
    }

    public void strBuildChecker(StringBuilder inpStrBuild) throws Exception
 	{
	 	if(inpStrBuild==null)
 		{
		throw new Exception("String builder can't be null");
		}
	}


    public StringBuilder appendTwo(StringBuilder inpStrBuild,String inputString,String inpString)throws Exception
    {
        obj.strChecker(inputString);
        obj.strChecker(inpString);
        strBuildChecker(inpStrBuild);
        inpStrBuild.append(inputString);
        inpStrBuild.append(" ");
        inpStrBuild.append(inpString);
        return inpStrBuild;
    }

//1

    public StringBuilder appendOne(StringBuilder inpBuilder,String inputString) throws Exception
    {
        strBuildChecker(inpBuilder);
        obj.strChecker(inputString);
        inpBuilder.append(inputString);
        return inpBuilder;
    }

//2

    public StringBuilder replaceHash(StringBuilder inpstrBuild,String inpStrArr[],String symbol) throws Exception
    {
        obj.checkStrArr(inpStrArr);
        int length=inpStrArr.length;
        strBuildChecker(inpstrBuild);
        for(int iterate=0;iterate<length;iterate++)
        {
            inpstrBuild.append(symbol);
            inpstrBuild.append(inpStrArr[iterate]);
        }
        return inpstrBuild;
    }

//3

    public StringBuilder insertBetweenString(StringBuilder strBuild,String inputString,String symbol) throws Exception
    {
        strBuildChecker(strBuild);
        obj.strChecker(inputString);
        int position=indexFirst(strBuild,symbol);
        strBuild.insert(position+1, inputString+" ");
        return strBuild;
    }

//4

    public StringBuilder strBuildDelete(StringBuilder inputStrBuild,String symbol)throws Exception
    {
        strBuildChecker(inputStrBuild);
        int position=indexFirst(inputStrBuild,symbol);
        inputStrBuild.delete(0,position+1);
        return inputStrBuild;
    }

//5

    public String spaceReplaceSymbol(StringBuilder inputString,String oldSymbol,String symbol) throws Exception
    {
        strBuildChecker(inputString);
        String noSpaceStr=inputString.toString().replaceAll(oldSymbol, symbol);
        return noSpaceStr;
    }

//6

    public StringBuilder strBuildReverse(StringBuilder strBuildInp) throws Exception
    {
        strBuildChecker(strBuildInp);
        strBuildInp.reverse();
        return strBuildInp;
    }

//7

	public void positionChecker(int firstPos,int lastPos,int posLength) throws Exception
	{
      	  if(firstPos>lastPos || firstPos>posLength ||lastPos>posLength||lastPos-firstPos>posLength)
     	   {
            throw new Exception("second number should be greater than first or The numbers should not be greater than string");
       	   }
	}

    public StringBuilder strDeleteIndex(StringBuilder inputstrBuild,int fromDel,int toDel) throws Exception
    {
        strBuildChecker(inputstrBuild);
        int posLength=getLength(inputstrBuild);
        positionChecker(fromDel,toDel,posLength);
        inputstrBuild.delete(fromDel,toDel);
        return inputstrBuild;
    }

//8

    public StringBuilder strReplaceIndex(StringBuilder inpStrBuild,String input,int firstPos,int lastPos) throws Exception
    {
          strBuildChecker(inpStrBuild);
          int posLength=getLength(inpStrBuild);
          obj.strChecker(input);
          positionChecker(firstPos,lastPos,posLength);
          inpStrBuild.replace(firstPos,lastPos,input);
          return inpStrBuild;
    }

//9 & //10

    public StringBuilder replaceHashTask(StringBuilder strBuild,String inpStrArr[],String symbol) throws Exception
    {
        strBuildChecker(strBuild);
        obj.checkStrArr(inpStrArr);
        int length=inpStrArr.length;
        for(int iterate=0;iterate<length;iterate++)
        {
            strBuild.append(inpStrArr[iterate]);
            strBuild.append(symbol);
        }
        int len=getLength(strBuild);
        strBuild=strDeleteIndex(strBuild,len-1,len);
        return strBuild;
    }

//9

    public int indexFirst(StringBuilder inpString,String symbol) throws Exception
    {
        strBuildChecker(inpString);
        int position=inpString.indexOf(symbol);
        return position;
    }

//10

    public int indexLast(StringBuilder inpString,String symbol)throws Exception
    {
        strBuildChecker(inpString);
        int position=inpString.lastIndexOf(symbol);
        return position;
    }
}
