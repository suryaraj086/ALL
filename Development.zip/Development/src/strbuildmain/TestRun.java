package strbuildmain;
import test.*;
import strbuild.*;
import java.util.*;

class TestRun
{
    public static void main(String[] args) {
        StringTask strObj = new StringTask();
        StringBuild strbObj=new StringBuild();
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the task number");
        int choice = 0;
        String inputString="";
        try {
            choice = scan.nextInt();
            if(choice!=10 && choice!=9 && choice!=6 && choice!=4 && choice!=5)
            {
            System.out.println("Enter your String");
            scan.nextLine();
            inputString = scan.nextLine();
            }
            else
            {
            scan.nextLine();
            }
        }
        catch (Exception e) {
            System.out.print("invalid number");
        }
        if (inputString == null) {
            System.out.println("Do not Enter null string");
        } else {
            switch (choice) 
            {
                case 1: 
                {
                    try
                    {
                        StringBuilder strBuildObj=strbObj.createSB();
                        System.out.println("The length with no string is "+strbObj.getLength(strBuildObj));
                        strBuildObj = strbObj.appendOne(strBuildObj,inputString);
                        System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 2: 
                {
                    try
                    {
                        StringBuilder strBuildObj=strbObj.createSB();
                        System.out.println("Enter the symbol");
                        String symbol=scan.nextLine();
                        System.out.println("Enter the length");
                        int length=scan.nextInt();
                        scan.nextLine();
                        String strArr[]=new String[length];
                        System.out.println("Enter the string array");
                        for(int iterate=0;iterate<length;iterate++)
                        {
                            strArr[iterate]=scan.nextLine();
                        }
                        strBuildObj=strbObj.appendOne(strBuildObj,inputString);
                        System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                        strBuildObj=strbObj.replaceHash(strBuildObj,strArr,symbol);
                        System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage()+"The length of array should be number");
                    }
                    break;
                }
                case 3:  
                 {
                    try
                    { 
                        StringBuilder strBuildObj=strbObj.createSB();
                        int strLength=strObj.strLength(inputString);
                        System.out.println("Enter the second string");
                        String inpString=scan.nextLine();
                        System.out.println("Enter the third string");
                        String inputStr=scan.nextLine();
                        System.out.println("Enter the symbol to find");
                        String symbol=scan.nextLine();
                        strBuildObj=strbObj.appendTwo(strBuildObj,inputString,inpString);
                        System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                        strBuildObj=strbObj.insertBetweenString(strBuildObj,inputStr,symbol);
                        System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 4:
                 {
                    try
                    {
                        StringBuilder strBuildObj=strbObj.createSB();
                        System.out.println("Enter the symbol to find");
                        String symbol=scan.nextLine();
                        System.out.println("Enter the length");
                        int length=scan.nextInt();
                        scan.nextLine();
                        String strArr[]=new String[length];
                        System.out.println("Enter the string array");
                        for(int iterate=0;iterate<length;iterate++)
                        {
                            strArr[iterate]=scan.nextLine();
                        }
                        strBuildObj=strbObj.replaceHashTask(strBuildObj,strArr," ");
                        System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                        strBuildObj=strbObj.strBuildDelete(strBuildObj,symbol);
                        System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 5:  
                 {
                    try
                    {
                        StringBuilder strBuildObj=strbObj.createSB();
                        System.out.println("Enter the length");
                        int length=scan.nextInt();
                        scan.nextLine();
                        String strArr[]=new String[length];
                        System.out.println("Enter the string array");
                        for(int iterate=0;iterate<length;iterate++)
                        {
                            strArr[iterate]=scan.nextLine();
                        }
                        strBuildObj=strbObj.replaceHashTask(strBuildObj,strArr," ");
                        System.out.println("Enter the old symbol to replace");
                        String oldSymbol=scan.nextLine();
                        System.out.println("Enter the symbol");
                        String symbol=scan.nextLine();
                        System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                        String str=strbObj.spaceReplaceSymbol(strBuildObj,oldSymbol,symbol);
                        System.out.println("The String is "+str+ " and the length is "+strObj.strLength(str));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 6:  
                {
                    try
                    {
                        StringBuilder strBuildObj=strbObj.createSB();
                        System.out.println("Enter the length");
                        int length=scan.nextInt();
                        scan.nextLine();
                        String strArr[]=new String[length];
                        System.out.println("Enter the string array");
                        for(int iterate=0;iterate<length;iterate++)
                        {
                            strArr[iterate]=scan.nextLine();
                        }
                        strBuildObj=strbObj.replaceHashTask(strBuildObj,strArr," ");
                        System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                        strBuildObj=strbObj.strBuildReverse(strBuildObj);
                        System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 7:  
                {
                    StringBuilder strBuildObj=strbObj.createSB();
                    int firstIndex=0;
                    int secondIndex=0;
                    try
                    {
                        System.out.println("Enter the starting number");
                        firstIndex=scan.nextInt();
                        System.out.println("Enter the Ending number");
                        secondIndex=scan.nextInt();                    
                        strBuildObj = strbObj.appendOne(strBuildObj,inputString);
                        System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                        strBuildObj = strbObj.strDeleteIndex(strBuildObj,firstIndex,secondIndex);
                        System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                    }
                    catch(Exception e){
                        System.out.println(e.getMessage()+" The postion should be numbers");
                    }
                    break;
                }
                case 8: 
                  {
                    StringBuilder strBuildObj=strbObj.createSB();
                    int firstIndex=0;
                    int secondIndex=0;
                    try
                    {
                        System.out.println("Enter the second string to replace");
                        String inpString=scan.nextLine();
                        System.out.println("Enter the starting number");
                        firstIndex=scan.nextInt();
                        System.out.println("Enter the Ending number");
                        secondIndex=scan.nextInt();
                        strBuildObj = strbObj.appendOne(strBuildObj,inputString);
                        System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                        strBuildObj = strbObj.strReplaceIndex(strBuildObj,inpString,firstIndex,secondIndex);
                        System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                    }
                    catch(Exception e){
                     System.out.println(e.getMessage()+" The postion should be numbers");
                    }
                    break;
                }
                case 9:   
                {
                    try
                     {
                        StringBuilder strBuildObj=strbObj.createSB();
                        System.out.println("Enter the symbol");
                        String symbol=scan.nextLine();
                        System.out.println("Enter the length");
                        int length=scan.nextInt();
                        scan.nextLine();
                        String strArr[]=new String[length];
                        System.out.println("Enter the string array");
                        for(int iterate=0;iterate<length;iterate++)
                        {
                            strArr[iterate]=scan.nextLine();
                        }
                        strBuildObj=strbObj.replaceHashTask(strBuildObj,strArr,symbol);
                        System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                        int position = strbObj.indexFirst(strBuildObj,symbol);
                        System.out.println("The first index position of given symbol is "+position);
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage()+" The length of array should be number");
                    }
                    break;
                }
                case 10:     
                {
                    try
                   {
                        StringBuilder strBuildObj=strbObj.createSB();
                        System.out.println("Enter the symbol");
                        String symbol=scan.nextLine();
                        System.out.println("Enter the length");
                        int length=scan.nextInt();
                        scan.nextLine();
                        String strArr[]=new String[length];
                        System.out.println("Enter the string array");
                        for(int iterate=0;iterate<length;iterate++)
                        {
                            strArr[iterate]=scan.nextLine();
                         
                        }
                            strBuildObj=strbObj.replaceHashTask(strBuildObj,strArr,symbol);
                            System.out.println("The String is "+strBuildObj+ " and the length is "+strbObj.getLength(strBuildObj));
                            int position =  strbObj.indexLast(strBuildObj,symbol);
                            System.out.println("The last index position of given symbol is "+position);
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage()+" The length of array should be number");
                    }
                    break;
                }
                default: 
                {
                    System.out.println("Enter Task Number between 1 to 10");
                }
            }
        }
        scan.close();
    }
}
