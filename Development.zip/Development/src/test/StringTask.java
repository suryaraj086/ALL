package test;
import java.util.*;

public class StringTask
{

    public void strChecker(String inpString) throws Exception
    {
        if (inpString == null || inpString.isEmpty()) 
        {

                throw new Exception("String can't be null or empty");
            
       
        }
    }

    public void intChecker(String inputStr,int length) throws Exception
    {
    strChecker(inputStr);
        if(length>inputStr.length() || length<0)
        {
      
                throw new Exception("length greater than string length or less than zero");
        }
      
    }

    

    public void checkStrArr(String strArr[]) throws Exception
	{
    for (String arrToStr:strArr) 
    {
     strChecker(arrToStr);
    }
	}


//1
    public int strLength(String leng) throws Exception
    {
    strChecker(leng);
    return leng.length();
    }    


//2
    public char[] charToArr(String strSource) throws Exception{
        strChecker(strSource);
        char[] chrar = strSource.toCharArray();     // or for loop can be used
    return chrar;
    }
//3
    public char findCharInPos(String srcString,int pos) throws Exception{
        strChecker(srcString);
        intChecker(srcString,pos);
        char[] charSrc = charToArr(srcString);   
        return  charSrc[pos];
    }
//4
    public int charOccurance(String inpStr, char findChar) throws Exception{
        int count = 0;
        int lenStr = strLength(inpStr);
        for (int i = 0; i < lenStr ; i++) {
            if (inpStr.charAt(i) == findChar)
            {
                count++;
            }
        }
        return count;
    }
//5
    public int greatPosChar(String srcStr, char findChar) throws Exception {
        strChecker(srcStr);
        int loc=srcStr.lastIndexOf(findChar);
        return loc;
    }
//6
    public String printLastChar(String firStr,int position) throws Exception {
        strChecker(firStr);
        intChecker(firStr,position);
        return firStr.substring(strLength(firStr) - position);
    }
//7
    public String printFirstChar(String srcString,int firstNum,int secNum) throws Exception {
        strChecker(srcString);
        return srcString.substring(firstNum, secNum);
    }
//8
    public String replaceFirstLetters(String firstString, String secondString,int startPos,int endPos) throws Exception  {
        strChecker(firstString);
        strChecker(secondString);
        secondString=firstString.substring(0,startPos)+secondString+firstString.substring(endPos);
        return secondString;
             
    }
//9
    public boolean checkStartChar(String firstInp, String startCheck) throws Exception  {
        strChecker(firstInp);
        strChecker(startCheck);
        return firstInp.startsWith(startCheck);
    }
//10
    public boolean checkEndChar(String firstStr, String endCheck) throws Exception{
         strChecker(firstStr);
        strChecker(endCheck);
        return firstStr.endsWith(endCheck);
    }

//11
    public String lowerCase(String strLower) throws Exception {
        strChecker(strLower);
        return strLower.toUpperCase();
    }
//12
    public String upperCase(String strUpper) throws Exception {
        strChecker(strUpper);
        return strUpper.toLowerCase();
    }
//13
    //string reverse
    public String strReverse(String strReverse) throws Exception {
        String refString = "";
        strChecker(strReverse);
        int strLen=strLength(strReverse);
        for (int i = strLen - 1; i >= 0; i--) {
            refString = refString + strReverse.charAt(i);
        }

        return refString;
    }
//14
    public String multiStrLine(String mulStr) throws Exception {
        strChecker(mulStr);
        return mulStr;
    }
//15
    public String multiStrNoSpace(String strNoSpace) throws Exception {
        strChecker(strNoSpace);
        String noSpaceStr = strNoSpace.replaceAll(" ", ""); // using built in method
        return noSpaceStr;

    }
//16
    public String[] multiStrArr(String mulStr) throws Exception {
        strChecker(mulStr);
        String strArr[] = mulStr.split(" ");
        return strArr;
    }
//17
    public String strMergeSymbol(String strArr[],String symbol) throws Exception  {
        checkStrArr(strArr);
        String strJoined = String.join(symbol, strArr);
        return strJoined;
    }

//18
    public boolean strCompareSensitive(String firstCompare, String secondCompare) throws Exception {
        strChecker(firstCompare);
        strChecker(secondCompare);
        return firstCompare.equals(secondCompare);
    }
//19
    public boolean strCompareInsensitive(String firstStrCompare, String secondStrCompare) throws Exception {
            strChecker(firstStrCompare);
        strChecker(secondStrCompare);
        return firstStrCompare.equalsIgnoreCase(secondStrCompare);
    }
//20
    public String strTrim(String trimmer) throws Exception {
        strChecker(trimmer);
        return trimmer.trim();
    }
}
