package test1;
import test.*;
import java.util.*;

class TestRunner
{
    public static void main(String[] args)
    {
        StringTask str = new StringTask();
        Scanner scn1 = new Scanner(System.in);
        System.out.println("Enter the task number");
        int choice = 0;
        String inputString = "";
        try
        {
            choice = scn1.nextInt();
            if (choice == 0 || choice == 17 ||choice == 1|| choice>20) 
            {
            }
            else
            {
                System.out.println("Enter your String");
                scn1.nextLine();
                inputString = scn1.nextLine();

            }
        }
        catch (Exception e)
        {
            System.out.print("invalid number");
        }
        if (inputString == null)
        {
            System.out.println("Do not Enter null string");
        } else
        {
            switch (choice) {
                case 1:
                {
                    try
                    {
                        if(args[0].isEmpty()||args[0]==null)
                        {
                            throw new Exception("The string can't be empty or null");
                        }
                        else
                        {
                            System.out.println("The length is "+str.strLength(args[0]));
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println(e);
                    }
                    break;
                }
                case 2:
                {
                    try
                    {
                        for(char charOut:str.charToArr(inputString))
                        {
                            System.out.println("The character is "+charOut);
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println("string can't be null or empty");
                    }

                    break;
                }
                case 3:
                {
                    int length=0;
                    try
                    {
                        System.out.println("Enter the length should be greater than zero");
                        length=scn1.nextInt();
                        System.out.println("The character is: " +str.findCharInPos(inputString,length-1));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 4:
                {
                    System.out.println("Enter a character");
                    char charInp = scn1.next().charAt(0);
                    try
                    {
                        System.out.println("Number of occurance is:" + str.charOccurance(inputString, charInp));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 5:
                {
                    System.out.println("Enter a character");
                    char charInput = scn1.next().charAt(0);
                    try
                    {
                        System.out.println("The index is"+str.greatPosChar(inputString, charInput));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }

                    break;
                }
                case 6:
                {
                    System.out.println("Enter the length");
                    int position = scn1.nextInt();
                    try
                    {
                        System.out.println("The last "+position+" character is: " +str.printLastChar(inputString,position));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 7:
                {
                    int postionInp=0;
                    int secPostionInp=0;
                    try
                    {
                        System.out.println("Enter the number ");
                        postionInp=scn1.nextInt();
                        System.out.println("Enter the second number" );
                        secPostionInp=scn1.nextInt();
                        if(secPostionInp<postionInp||postionInp>str.strLength(inputString)||secPostionInp>str.strLength(inputString))
                        {
                            throw new Exception("Enter the correct position to find");
                        }
                        else
                        {
                            System.out.println("The first character is: " + str.printFirstChar(inputString,postionInp,secPostionInp+1));
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 8:
                {

                    String stringd2 = "";
                    try
                    {
                        System.out.println("Enter the first number");
                        int posInp = scn1.nextInt();
                        System.out.println("Enter the second number");
                        int posInput = scn1.nextInt();
                        scn1.nextLine();
                        System.out.println("Enter the string to replace the characters");
                        stringd2= scn1.nextLine();
                        if (posInput<posInp|| posInp>str.strLength(inputString) || posInput>str.strLength(inputString))
                        {
                            System.out.println("Enter a valid string or number");
                        }
                        else
                        {
                            System.out.println("The changed string is: " +str.replaceFirstLetters(inputString,stringd2,posInp,posInput+1));
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage()+" The input number should be integer");
                    }
                    break;
                }
                case 9:
                {
                    System.out.println("Enter the string to check the first characters");
                    String secondStr = scn1.nextLine();
                    try
                    {
                        if (secondStr.isEmpty() || secondStr==null|| str.strLength(secondStr) > str.strLength(inputString))
                        {
                            System.out.println("Enter a valid string");
                        } else
                        {
                            System.out.println("Is the string starts with " + str.checkStartChar(inputString, secondStr));
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 10:
                {
                    System.out.println("Enter the string to check the last characters");
                    String inpStr = scn1.nextLine();
                    try
                    {
                        if (inpStr.isEmpty()|| inpStr==null || str.strLength(inpStr) > str.strLength(inputString))
                        {
                            System.out.println("Enter a valid string");
                        }
                        else
                        {
                            System.out.println("Is the string ends with " + str.checkEndChar(inputString, inpStr));
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 11:
                {
                    try
                    {
                        System.out.println("The upper case is: " + str.lowerCase(inputString));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 12:
                {
                    try
                    {
                        System.out.println("The lower case is: " + str.upperCase(inputString));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 13:
                {
                    try
                    {
                        System.out.print("The reverse string is: " + str.strReverse(inputString));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 14:
                {
                    try
                    {
                        System.out.println(str.multiStrLine(inputString));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 15:
                {
                    try
                    {
                        System.out.println(str.multiStrNoSpace(inputString));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 16:
                {
                    try
                    {
                        for(String strOup:str.multiStrArr(inputString))
                        {
                            System.out.println("The string aray is "+strOup);
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }

                    break;
                }
                case 17:
                {
                    System.out.println("Enter the length of string array");
                    int arrLen = 0;
                    String inputStr="";
                    try
                    {
                        arrLen = scn1.nextInt();
                        scn1.nextLine();
                        System.out.println("Enter the one symbol");
                        inputStr = scn1.nextLine();
                        String arr[] = new String[arrLen];
                        System.out.println("Enter the string array");

                        for (int i = 0; i < arrLen; i++)
                        {
                            arr[i] = scn1.nextLine();
                        }
                        System.out.println(str.strMergeSymbol(arr,inputStr));
                    }
                    catch(Exception e)
                    {
                        System.out.println("The number should be positive integer and symbol should be single character");
                    }

                    break;
                }
                case 18:
                {
                    System.out.println("Enter the another string");
                    String compareStr = scn1.nextLine();
                    try
                    {
                        if (compareStr.isEmpty() || compareStr==null)
                        {
                            System.out.println("Enter a valid string");
                        } else
                        {
                            System.out.println("Is the strings are same: " +  str.strCompareSensitive(inputString, compareStr));
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 19:
                {
                    System.out.println("Enter the another string");
                    String compareString = scn1.nextLine();
                    try
                    {
                        if (compareString.isEmpty()|| compareString==null)
                        {
                            System.out.println("Enter a valid string");
                        } else
                        {
                            System.out.println("Is the strings are same: " +str.strCompareInsensitive(inputString, compareString));
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 20:
                {
                    try
                    {
                        System.out.println("The string is"+ str.strTrim(inputString));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                default: {
                    System.out.println("Enter Task Number between 1 to 20");
                }
            }
        }
        scn1.close();
    }
}
